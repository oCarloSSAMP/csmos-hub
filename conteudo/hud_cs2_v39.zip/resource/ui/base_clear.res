"Resource/UI/base_clear.res"
{
	"clear" 
	{
		"ControlName"	"ImagePanel"
		"xpos"			"0"
		"ypos"			"0"
		"zpos"			"-5"
		"wide"			"f"
		"tall"			"f"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/ff"
		"scaleImage"	"1"	
	}
	}
}
