#base "base_num_5.res"

"Resource/UI/base_num_6.res"
{
	"number_6"
	{
		"ControlName"	"Label"
		"fieldName"		"number_6"
		"xpos"			"120" // 27
		"ypos"			"156" // 25
		"zpos"			"3"
		"wide"			"22"
		"tall"			"22"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"tabPosition"	"0"
		"font"			"BuyMenuNames"
		"labelText"		"6"
		"fgcolor_override"  "BuyMenuNumbersColor"
		"textAlignment"	"center"
		"dulltext"		"0"
		"brighttext"	"0"
	}
}	