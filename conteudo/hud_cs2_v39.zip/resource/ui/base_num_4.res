#base "base_num_3.res"

"Resource/UI/base_num_4.res"
{
	"number_4"
	{
		"ControlName"	"Label"
		"fieldName"		"number_4"
		"xpos"			"120"
		"ypos"			"157"
		"zpos"			"3"
		"wide"			"22"
		"tall"			"22"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"tabPosition"	"0"
		"font"			"BuyMenuNames"
		"labelText"		"4"
		"fgcolor_override"  "BuyMenuNumbersColor"
		"textAlignment"	"center"
		"dulltext"		"0"
		"brighttext"	"0"
	}
}	