"resource/hud/healtharmor.res"
{	
	"HealthLabel"
	{
		"fieldName"			"HealthLabel"
		"xpos"				"66"
		"ypos"				"0"
		"wide"				"72"
		"tall"				"51"
		
		"textAlignment"		"center"
		"font"				"HealthArmorFont"
		"fgcolor_override"	"TheHudColorLmfao"
	}
	"HealthProgress"
	{
		"fieldName"			"HealthProgress"
		"xpos"				"90"
		"ypos"				"35"
		"wide"				"27"
		"tall"				"5"
		
		"fgcolor_override"	"White"
		"bgcolor_override"	"102 102 102 153"
		"border"				"HealthArmorProgressBorder"
	}
	"HealthIcon"
	{
		"fieldName"			"HealthIcon"
		"xpos"				"14"
		"ypos"				"35"
		"wide"				"12"
		"tall"				"12"
      "enabled" "0" 
		"visible" "0" 
		"fgcolor_override"	"TheHudColorLmfao"

		"image"				"materials/vgui/hud/svg/health.svg"
	}
	
	"ArmorLabel"
	{
		"fieldName"			"ArmorLabel"
		"xpos"				"38"
		"ypos"				"4"
		"wide"				"74"
		"tall"				"53"
		
		"textAlignment"		"center"
		"font"				"ArmorFont"
		"fgcolor_override"	"TheHudColorLmfao"
	}
	"SimpleArmorLabel"
	{
		"fieldName"			"SimpleArmorLabel"
		"xpos"				"75"
		"ypos"				"-14"
		"wide"				"74"
		"tall"				"53"
		 
		"textAlignment"		"center"
		"font"				"HealthArmorFont"
		"fgcolor_override"	"TheHudColorLmfao"
	}
	"ArmorProgress"
	{
		"fieldName"			"ArmorProgress"
		"xpos"				"153"
		"ypos"				"12"
		"wide"				"50"
		"tall"				"5"
      "enabled" "0" 
      "visible" "0" 
		
		"fgcolor_override"	"0 0 0 0"
		"bgcolor_override"	"0 0 0 0" 
		"border"			"HealthArmorProgressBorder"
	}
	"ArmorIcon"
	{
		"fieldName"			"ArmorIcon"
		"xpos"				"110"
		"ypos"				"40"
		"wide"				"25" 
		"tall"				"45" 
		 
		"fgcolor_override"	"TheHudColorLmfao"

		"image"				"materials/vgui/hud/svg/shield.svg"
	}
	"HelmetIcon"
	{
		"fieldName"			"HelmetIcon"
		"xpos"				"110"
		"ypos"				"40"
		"wide"				"25" 
		"tall"				"45"
		
		"fgcolor_override"	"TheHudColorLmfao" 

		"image"				"materials/vgui/hud/svg/helmet.svg"
	}
}
