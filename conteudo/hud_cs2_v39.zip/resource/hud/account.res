"resource/hud/account.res"
{
	"AccountLabel"
	{
		"fieldName"			"AccountLabel"
		"xpos"				"19"
		"ypos"				"2"
		"wide"				"128"
		"tall"				"49"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"textAlignment"		"west"
		"font"				"HealthArmorFont"
		"fgcolor_override"	"TheHudColorLmfao"
	}

	"BuyZoneIcon"
	{
		"fieldName"			"BuyZoneIcon"
		"xpos"				"12"
		"ypos"				"-3"
		"wide"				"40"
		"tall"				"40"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"pin_to_sibling"			"AccountLabel"
		"pin_corner_to_sibling"	"7"
		"pin_to_sibling_corner"	"5"
		"fgcolor_override"	"255 177 54 180"

		"image"				"materials/vgui/hud/svg/buyzone.svg"
	}
}