"resource/hud/teamcounter.res"
{	
	"RoundTimerLabel"
	{
		"fieldName"			"RoundTimerLabel"
		"xpos"				"75"
		"ypos"				"0"
		"wide"				"43"
		"tall"				"14"
	
		"textAlignment"		"center"
		"font"				"RoundTimerFont"
		"fgcolor_override"		"HudMainColor"
		
		"bgcolor_override"	"0 0 0 240"
		"PaintBackgroundType"	"0"
	}
	
	"BombIcon"
	{
		"fieldName"			"BombIcon"
		"xpos"				"86"
		"ypos"				"-3"
		"wide"				"22" // 42
		"tall"				"22" // 14 
		

		"image"				"hud/C4"
		"scaleImage"			"1"
	}
	"CTAliveBgImage"
	{
		"ControlName"			"ImagePanel"
		"fieldName"			"CTAliveBgImage" 
		"xpos"				"48"
		"ypos"				"0"
		"wide"				"26"
		"tall"				"35"
      
		
		"image"				"hud/teamcounter_alivebg"
		"scaleImage"			"1"
		"zpos"				"-1"
	}
	"TAliveBgImage"
	{
		"ControlName"			"ImagePanel"
		"fieldName"			"TAliveBgImage"
		"xpos"				"119"
		"ypos"				"0"
		"wide"				"26"
		"tall"				"35"
		"image"				"hud/teamcounter_alivebg"
		"scaleImage"			"1"
		"zpos"				"-1"
	}
   "CTWinCounterLabel"
	{
		"fieldName"			"CTWinCounterLabel"
		"xpos"				"74"
		"ypos"				"16"
		"wide"				"21"
		"tall"				"19"
	
		"textAlignment"		"center"
		"font"				"RoundTimerFont"
		"fgcolor_override"	"181 211 235 255"

		 "bgcolor_override"	"0 0 0 0"
		"PaintBackgroundType"	"0"
	}
	"CTAliveCounterLabel"
	{
		"fieldName"			"CTAliveCounterLabel"
		"xpos"				"35"
		"ypos"				"-14"
		"wide"				"51"
		"tall"				"53"
		
		"textAlignment"		"center"
		"font"				"AliveCountFont"
		"fgcolor_override"	"181 211 235 255"
	}
	"CTAliveTextLabel"
	{
		"fieldName"			"CTAliveTextLabel"
		"xpos"				"35"
		"ypos"				"15"
		"wide"				"51"
		"tall"				"18"
		
		"textAlignment"		"center"
		"font"				"AliveTextFont"
		"fgcolor_override"	"White"
		"labelText"			"#Cstrike_PlayerCount_Alive"
	}
	"CTSkullImage"
	{
		"fieldName"			"CTSkullImage"
		"xpos"				"50"
		"ypos"				"4"
		"wide"				"22"
		"tall"				"22"
		
		"image"				"hud/teamcounter_aliveskull"
		"scaleImage"			"1"
    }
	"TWinCounterLabel"
	{
		"fieldName"			"TWinCounterLabel"
		"xpos"				"96"
		"ypos"				"16"
		"wide"				"22"
		"tall"				"19"
		
		"textAlignment"		"center"
		"font"				"RoundTimerFont"
		"fgcolor_override"	"209 189 128 255"
		
		"bgcolor_override"	"0 0 0 0"
		"PaintBackgroundType"	"0"
	}
	"TAliveCounterLabel"
	{
		"fieldName"			"TAliveCounterLabel"
		"xpos"				"106"
		"ypos"				"-14"
		"wide"				"51"
		"tall"				"53"
		
		"textAlignment"		"center"
		"font"				"AliveCountFont"
		"fgcolor_override"	"209 189 128 255"
	}
	"TAliveTextLabel"
	{
		"fieldName"			"TAliveTextLabel"
		"xpos"				"106"
		"ypos"				"15"
		"wide"				"51"
		"tall"				"18"
		
		"textAlignment"		"center"
		"font"				"AliveTextFont"
		"fgcolor_override"	"White"
		"labelText"			"#Cstrike_PlayerCount_Alive"
	}
	"TSkullImage"
	{
		"fieldName"			"TSkullImage"
		"xpos"				"121"
		"ypos"				"4"
		"wide"				"22"
		"tall"				"22"
		
		"image"				"hud/teamcounter_aliveskull"
		"scaleImage"			"1"
}
    "WinBgImage"
	{
		"ControlName"			"ImagePanel"
		"fieldName"			"WinBgImage"
		"xpos"				"97"
		"ypos"				"5"
		"wide"				"21"
		"tall"				"31"
		
		"image"				"hud/BGWIN"
		"scaleImage"			"1"
		"zpos"				"-1"
   }
   "WinBgImage1"
	{
		"ControlName"			"ImagePanel"
		"fieldName"			"WinBgImage1"
		"xpos"				"75"
		"ypos"				"5"
		"wide"				"21"
		"tall"				"31"
		
		"image"				"hud/BGWIN"
		"scaleImage"			"1"
		"zpos"				"-1"

	}
}
