"resource/hud/notificationpanel.res"
{
	"NotificationPanel"
	{
		"fieldName" "NotificationPanel"
		"xpos"	"c-200"
		"ypos"	"850"
		"wide"	"400"
		"tall"  "76"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"visible" "1"
		"enabled" "1"

		"PaintBackgroundType"	"1"
		"bgcolor_override"	"TheHudColorLmfao"
		"Texture1"			"vgui/hud/NotifBG"
		
		"alpha"				"0" // unhidden via vgui animation
		"alert_icon_margin"	"8"
		"bottom_margin"		"11"
	}
	"BorderUpper"
	{
		"controlName"			"ImagePanel"
		"fieldName"			"BorderUpper"
		"xpos"				"0"
		"ypos"				"0"
		"wide"				"400"
		"tall"				"i1"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"fgcolor_override"	"0 0 0 0"

		"scaleImage"			"1"
		"image"				"hud/notification_border"
	}
	"BorderBottom"
	{
		"fieldName"			"BorderBottom"
		"xpos"				"0"
		"ypos"				"ir1"
		"wide"				"750"
		"tall"				"i1"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"fgcolor_override"	"White"

		"scaleImage"			"1"
		"image"				"hud/notification_border"
    } 
    "AlertTitleLabel"
	{
		"fieldName"			"AlertTitleLabel"
		"xpos"				"-400"
		"ypos"				"12"
		"wide"				"400"
		"tall"				"20"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
	  "textAlignment"		"west"
		"font"				"NotificationTitleFont"
		"text"				"#UI_Alert"
		"fgcolor_override"	"255 255 255 100"
	}
  "AlertIcon"
	{
		"fieldName"			"AlertIcon"
		"xpos"				"350"
		"ypos"				"10"
		"wide"				"20"
		"tall"				"20"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"fgcolor_override"	"255 255 255 100"

		"image"				"materials/vgui/hud/svg/alert.svg"
	}

	"InfoIcon"
	{
		"fieldName"			"InfoIcon"
		"xpos"				"500"
		"ypos"				"10"
		"wide"				"20"
		"tall"				"20"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"fgcolor_override"	"255 255 255 100"

		"image"				"materials/vgui/hud/svg/info.svg"
	}
	"NotificationText"
	{
		"fieldName"			"NotificationText"
		"xpos"				"-175" 
		"ypos"				"35"
		"wide"				"750"
		"tall"				"32"
		"base_resolution_wide" "1920"
		"base_resolution_tall" "1080"
		"textAlignment"		"north"
		"font"				"NotificationTextFont"
		"fgcolor_override"	"White"
	}
}