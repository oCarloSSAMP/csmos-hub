#base "base_weapon.res"

"classes/ump45.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_UMP45"
	}
	"clipcapacity_label"
	{
		"labelText"		"25/100"
	}
	"killaward_label"
	{
		"labelText"		"$600(300%)"
	}
	"damage_label"
	{
		"labelText"		"35"
	}
	"firerate_label"
	{
		"labelText"		"11"
	}
	"recoilcontrol_label"
	{
		"labelText"		"77"
	}
	"accuraterange_label"
	{
		"labelText"		"11m"
	}
	"armorpenetration_label"
	{
		"labelText"		"130"
	}	
	"classimage"
	{
		"weaponName"		"weapon_ump45"
	}
	"select_3"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"91"		
	}
	"br_1"
	{
	    "xpos"          "97"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"90"		
	}
	"br_2"
	{
	    "xpos"          "96"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"204"		
	}
	"br_3"
	{
	    "xpos"          "210"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"50"		
	}
	"br_4"
	{
	    "xpos"          "56"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"168"		
	}
	"br_5"
	{
	    "xpos"          "174"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}