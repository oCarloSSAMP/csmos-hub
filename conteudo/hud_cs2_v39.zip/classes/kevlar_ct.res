
#base "base_equipment_image_ct.res"

"classes/kevlar.res"
{ 
	"classimage"
	{
		"weaponName"		"item_kevlar"
{
	"select_x_1"
	{
		"visible"		"1"	
	}	
}
		"1"	
	}	
}