#base "base_weapon_ct.res"

"classes/fiveseven_cz75_slct.res"
{
	"weaponname_label"
	{
		"labelText"	            "Five-SeveN | CZ75-Auto"
	}
	"clipcapacity_label"
	{
		"labelText"  	        "20/100 | 12/12"
	}	
	"killaward_label"
	{
		"labelText"	            "$300(150%) | $100(50%)"
	}
	"damage_label"
	{
		"labelText"  	        "32 | 31"
	}	
	"firerate_label"
	{
		"labelText"  	        "6 | 10"
	}
	"recoilcontrol_label"
	{
		"labelText"	        "75 | 69"
	}
	"accuraterange_label"
	{
		"labelText"  	        "13m | 11m"
	}
	"armorpenetration_label"
	{
		"labelText"	        "182 | 154"
	}	
	"classimage"
	{
		"weaponName"		"weapon_cz75"
	}
	"select_4"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"80"		
	}
	"br_1"
	{
	    "xpos"          "86"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"177"		
	}
	"br_2"
	{
	    "xpos"          "183"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"198"		
	}
	"br_3"
	{
	    "xpos"          "204"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"66"		
	}
	"br_4"
	{
	    "xpos"          "72"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"202"		
	}
	"br_5"
	{
	    "xpos"          "208"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
