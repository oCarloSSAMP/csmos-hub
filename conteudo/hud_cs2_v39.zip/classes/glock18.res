#base "base_weapon.res"

"classes/glock18.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Glock18"
	}
	"clipcapacity_label"
	{
		"labelText"		"20/120"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"30"
	}
	"firerate_label"
	{
		"labelText"		"6"
	}
	"recoilcontrol_label"
	{
		"labelText"		"82"
	}
	"accuraterange_label"
	{
		"labelText"		"20m"
	}
	"armorpenetration_label"
	{
		"labelText"		"94"
	}	
	"classimage"
	{
		"weaponName"		"weapon_glock"
	}
	"select_1"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"77"		
	}
	"br_1"
	{
	    "xpos"          "83"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"110"		
	}
	"br_2"
	{
	    "xpos"          "116"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"212"		
	}
	"br_3"
	{
	    "xpos"          "218"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"51"		
	}
	"br_4"
	{
	    "xpos"          "57"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"121"		
	}
	"br_5"
	{
	    "xpos"          "127"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
