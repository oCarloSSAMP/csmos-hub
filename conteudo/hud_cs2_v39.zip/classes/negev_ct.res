#base "base_weapon_ct.res"

"classes/negev_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Negev"
	}
	"clipcapacity_label"
	{
		"labelText"		"150/300"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"35"
	}
	"firerate_label"
	{
		"labelText"		"13"
	}
	"recoilcontrol_label"
	{
		"labelText"		"80"
	}
	"accuraterange_label"
	{
		"labelText"		"12m"
	}
	"armorpenetration_label"
	{
		"labelText"		"142"
	}	
	"classimage"
	{
		"weaponName"		"weapon_negev"
	}
	"select_5"
	{
		"visible"		"1"		
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"90"		
	}
	"br_1"
	{
	    "xpos"          "96"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"233"		
	}
	"br_2"
	{
	    "xpos"          "239"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"206"		
	}
	"br_3"
	{
	    "xpos"          "212"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"52"		
	}
	"br_4"
	{
	    "xpos"          "58"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"183"		
	}
	"br_5"
	{
	    "xpos"          "189"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
"4"
		"visible"		"1"
		"wide"			"2"		
	}	
}