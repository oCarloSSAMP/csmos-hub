#base "base_grenade_ct.res"

"classes/hegrenade_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_HE_Grenade"
	}
	"weaponcost_label"
	{
		"labelText"		"$300"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_HEGrenadeDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_hegrenade"
	}
	"select_4"
	{
		"visible"		"1"		
	}	
}
	}
	"select_4"
	{
		"visible"		"1"		
	}	
}