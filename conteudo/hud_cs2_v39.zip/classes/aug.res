#base "base_weapon_ct.res"

"classes/aug.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Aug"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"28"
	}
	"firerate_label"
	{
		"labelText"		"10"
	}
	"recoilcontrol_label"
	{
		"labelText"		"76"
	}
	"accuraterange_label"
	{
		"labelText"		"31m"
	}
	"armorpenetration_label"
	{
		"labelText"		"180"
	}	
	"classimage"
	{
		"weaponName"		"weapon_aug"
	}
	"select_4"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"72"		
	}
	"br_1"
	{
	    "xpos"          "78"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"170"		
	}
	"br_2"
	{
	    "xpos"          "176"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"196"		
	}
	"br_3"
	{
	    "xpos"          "202"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"76"		
	}
	"br_4"
	{
	    "xpos"          "82"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"232"		
	}
	"br_5"
	{
	    "xpos"          "238"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
