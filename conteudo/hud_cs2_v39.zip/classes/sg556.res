#base "base_weapon.res"

"classes/sg556.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_SG556"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"30"
	}
	"firerate_label"
	{
		"labelText"		"9"
	}
	"recoilcontrol_label"
	{
		"labelText"		"72"
	}
	"accuraterange_label"
	{
		"labelText"		"23m"
	}
	"armorpenetration_label"
	{
		"labelText"		"200"
	}	
	"classimage"
	{
		"weaponName"		"weapon_sg556"
	}
	"select_4"
	{
		"visible"		"1"	
	}	
	"num_1"
	{
		"visible"		"1"
		"wide"			"77"		
	}
	"br_1"
	{
	    "xpos"          "83"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"150"		
	}
	"br_2"
	{
	    "xpos"          "156"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"185"		
	}
	"br_3"
	{
	    "xpos"          "191"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"86"		
	}
	"br_4"
	{
	    "xpos"          "92"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_5"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}