#base "base_equipment.res"

"classes/nightvision.res"
{
	"price"
	{
		"labelText"		"#Cstrike_NightVisionPrice"
	}
}