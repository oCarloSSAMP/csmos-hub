#base "base_weapon_ct.res"

"classes/awp_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_AWP"
	}
	"clipcapacity_label"
	{
		"labelText"		"10/30"
	}
	"killaward_label"
	{
		"labelText"		"$100(50%)"
	}
	"damage_label"
	{
		"labelText"		"115"
	}
	"firerate_label"
	{
		"labelText"		"0.6"
	}
	"recoilcontrol_label"
	{
		"labelText"		"22"
	}
	"accuraterange_label"
	{
		"labelText"		"70m"
	}
	"armorpenetration_label"
	{
		"labelText"		"194"
	}	
	"classimage"
	{
		"weaponName"		"weapon_awp"
	}
	"select_5"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_1"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"98"		
	}
	"br_2"
	{
	    "xpos"          "104"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"56"		
	}
	"br_3"
	{
	    "xpos"          "62"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"180"		
	}
	"br_4"
	{
	    "xpos"          "186"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"250"		
	}
	"br_5"
	{
	    "xpos"          "256"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}
}
