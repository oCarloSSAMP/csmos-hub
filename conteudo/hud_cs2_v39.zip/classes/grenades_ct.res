#base "player_image_ct.res"

"classes/grenades_ct.res"
{
	"selection_image"
	{
		"ControlName"	"ImagePanel"
		"xpos"			"3"
		"ypos"			"2"
		"zpos"			"2"
		"wide"			"273"
		"tall"			"273"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/vgui/hud_buy_select/select_6_ct"
		"scaleImage"	"1"		
	}	
}