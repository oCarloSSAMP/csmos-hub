"classes/icon_ct.res"
