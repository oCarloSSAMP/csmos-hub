#base "base_equipment_image.res"

"classes/kevlar_helmet.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Kevlar_Helmet"
	}
	"weaponcost_label"
	{
		"labelText"		"$1000"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_KevlarHelmetDescription"
	}	
	"classimage"
	{
		"weaponName"		"item_assaultsuit"
	}
	"select_x_2"
	{
		"visible"		"1"	
	}	
}
e"		"1"	
	}	
}