#base "base_weapon_ct.res"

"classes/p90_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_P90"
	}
	"clipcapacity_label"
	{
		"labelText"		"50/100"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"26"
	}
	"firerate_label"
	{
		"labelText"		"14"
	}
	"recoilcontrol_label"
	{
		"labelText"		"84"
	}
	"accuraterange_label"
	{
		"labelText"		"10m"
	}
	"armorpenetration_label"
	{
		"labelText"		"138"
	}	
	"classimage"
	{
		"weaponName"		"weapon_p90"
	}
	"select_4"
	{
		"visible"		"1"		
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"67"		
	}
	"br_1"
	{
	    "xpos"          "73"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_2"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"217"		
	}
	"br_3"
	{
	    "xpos"          "223"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"43"		
	}
	"br_4"
	{
	    "xpos"          "49"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"178"		
	}
	"br_5"
	{
	    "xpos"          "184"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}

		"visible"		"1"
		"wide"			"2"		
	}	
}