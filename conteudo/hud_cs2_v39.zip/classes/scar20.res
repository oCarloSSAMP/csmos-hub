#base "base_weapon_ct.res"

"classes/scar20.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_SCAR20"
	}
	"clipcapacity_label"
	{
		"labelText"		"20/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"80"
	}
	"firerate_label"
	{
		"labelText"		"4"
	}
	"recoilcontrol_label"
	{
		"labelText"		"69"
	}
	"accuraterange_label"
	{
		"labelText"		"66m"
	}
	"armorpenetration_label"
	{
		"labelText"		"164"
	}	
	"classimage"
	{
		"weaponName"		"weapon_scar20"
	}
	"select_6"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"206"		
	}
	"br_1"
	{
	    "xpos"          "212"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"54"		
	}
	"br_2"
	{
	    "xpos"          "60"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"178"		
	}
	"br_3"
	{
	    "xpos"          "184"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"201"		
	}
	"br_4"
	{
	    "xpos"          "207"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"213"
	}
	"br_5"
	{
	    "xpos"          "219"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}