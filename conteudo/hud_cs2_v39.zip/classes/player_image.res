
"classes/player_image.res"
{
	"playerimage"
	{
		"ControlName"	"CCSBuyMenuPlayerImagePanel"
		"fieldName"		"playerimage"
		"xpos"			"c+130"
		"ypos"			"20"
		"wide"			"300"
		"tall"			"440"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"textAlignment"	"center"
		"scaleImage"	"1"
		"view_xpos"		"-92"
		"view_ypos"		"-10"
		"view_zpos"		"55"
		"zpos"			"1"
	}	
}