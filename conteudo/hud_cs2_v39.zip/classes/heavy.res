#base "player_image.res"

"classes/heavy.res"
{
	"selection_image"
	{
		"ControlName"	"ImagePanel"
		"xpos"			"3"
		"ypos"			"2"
		"zpos"			"2"
		"wide"			"273"
		"tall"			"273"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/vgui/hud_buy_select/select_2_tr"
		"scaleImage"	"1"		
	}
}