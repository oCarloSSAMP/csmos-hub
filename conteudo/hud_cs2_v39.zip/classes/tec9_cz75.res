#base "base_weapon.res"

"classes/tec9_cz75.res"
{
	"price"
	{
		"labelText"		"#Cstrike_FivesevenPrice"
	}	
	"classimage"
	{
		"weaponName"		"weapon_cz75"
	}
}
