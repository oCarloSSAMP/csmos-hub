#base "base_weapon_ct.res"

"classes/deagle_revolver_ct.res"
{

}