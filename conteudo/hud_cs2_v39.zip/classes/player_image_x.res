#base "x_panel.res"
#base "icon_tr.res"

"classes/player_image_x.res"
{
	"playerimage"
	{
		"ControlName"	"CCSBuyMenuPlayerImagePanel"
		"fieldName"		"playerimage"
		"xpos"			"c-80"
		"ypos"			"0"
		"wide"			"524"
		"tall"			"441"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"textAlignment"	"center"
		"scaleImage"	"1"
		"view_xpos"		"-92"
		"view_ypos"		"-3"
		"view_zpos"		"55"
		"zpos"			"1"
	}
}