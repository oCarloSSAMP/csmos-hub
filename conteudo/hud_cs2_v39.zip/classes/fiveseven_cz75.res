#base "base_weapon_ct.res"

"classes/fiveseven_cz75.res"
{
	"price"
	{
		"labelText"		"#Cstrike_FivesevenPrice"
	}	
	"classimage"
	{
		"weaponName"		"weapon_fiveseven"
	}
	
}
