#base "base_weapon_ct.res"

"classes/m4a4_m4a1.res"
{
	
}