
"classes/base_equipment_image.res"
{
	"classimage"
	{
		"ControlName"	"CSBuyMenuImagePanel"
		"fieldName"		"classimage"
		"xpos"			"225"
		"ypos"			"-10"
		"wide"			"300"
		"tall"			"440"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"textAlignment"	"center"
		"scaleImage"	"1"
		"3DModel"		"nothing_is_here"
		"AnimName"		"UI_BuyMenu_armor"
		"view_xpos"		"-92"
		"view_ypos"		"-10"
		"view_zpos"		"55"
		"zpos"			"1"		
	}
	"stats_base_alt"
	{
		"visible"		"1"	
	}	
}