#base "base_grenade.res"

"classes/molotov.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Molotov"
	}
	"weaponcost_label"
	{
		"labelText"		"$400"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_MolotovDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_molotov"
	}
	"select_1"
	{
		"visible"		"1"		
	}	
}

	"select_1"
	{
		"visible"		"1"		
	}	
}