#base "base_weapon_ct.res"

"classes/deagle_revolver_ct_slct.res"
{
	"weaponname_label"
	{
		"labelText"	        "Desert Eagle | R8 Revolver"
	}
	"clipcapacity_label"
	{
		"labelText"	        "7/35 | 8/8"
	}
	"killaward_label"
	{
		"labelText"		    "$300(150%)"
	}
	"damage_label"
	{
		"labelText"	        "31 | 86"

	}	
	"firerate_label"
	{
		"labelText"	        "4 | 2"
	}
	"recoilcontrol_label"
	{
		"labelText"	        "52 | 80"
	}
	"accuraterange_label"
	{
		"labelText"	            "24m | 16m"
	}
	"armorpenetration_label"
	{
		"labelText"		"186"
	}	
	"classimage"
	{
		"weaponName"		"weapon_deagle"
	}
	"select_5"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"162"		
	}
	"br_1"
	{
	    "xpos"          "168"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"60"		
	}
	"br_2"
	{
	    "xpos"          "66"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"134"		
	}
	"br_3"
	{
	    "xpos"          "140"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"61"		
	}
	"br_4"
	{
	    "xpos"          "67"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"240"		
	}
	"br_5"
	{
	    "xpos"          "246"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}
}
