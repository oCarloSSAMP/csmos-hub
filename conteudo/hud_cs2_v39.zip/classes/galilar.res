#base "base_weapon.res"

"classes/galilar.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_GalilAR"
	}
	"clipcapacity_label"
	{
		"labelText"		"35/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"30"
	}
	"firerate_label"
	{
		"labelText"		"11"
	}
	"recoilcontrol_label"
	{
		"labelText"		"79"
	}
	"accuraterange_label"
	{
		"labelText"		"16m"
	}
	"armorpenetration_label"
	{
		"labelText"		"155"
	}	
	"classimage"
	{
		"weaponName"		"weapon_galilar"
	}
	"select_1"
	{
		"visible"		"1"	
	}	
	"num_1"
	{
		"visible"		"1"
		"wide"			"77"		
	}
	"br_1"
	{
	    "xpos"          "83"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"195"		
	}
	"br_2"
	{
	    "xpos"          "201"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"204"		
	}
	"br_3"
	{
	    "xpos"          "210"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"41"		
	}
	"br_4"
	{
	    "xpos"          "47"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"200"		
	}
	"br_5"
	{
	    "xpos"          "206"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}