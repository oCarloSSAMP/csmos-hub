"classes/base_equipment.res"
{
	"pricelabel"
	{
		"ControlName"		"Label"
		"fieldName"		"pricelabel"
		"xpos"		"335"
		"ypos"		"115"
		"wide"		"150"
		"tall"		"24"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"labelText"		"#Cstrike_PriceLabel"
		"textAlignment"		"west"
		"dulltext"		"1"
		"brighttext"		"0"
	}

	"price"
	{
		"ControlName"		"Label"
		"fieldName"		"price"
		"xpos"		"430"
		"ypos"		"115"
		"wide"		"150"
		"tall"		"24"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"labelText"		"#Cstrike_KevlarPrice"
		"textAlignment"		"west"
		"dulltext"		"1"
		"brighttext"		"0"
	}
}