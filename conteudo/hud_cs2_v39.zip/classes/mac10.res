#base "base_weapon.res"

"classes/mac10.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_MAC10"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/100"
	}
	"killaward_label"
	{
		"labelText"		"$600(300%)"
	}
	"damage_label"
	{
		"labelText"		"29"
	}
	"firerate_label"
	{
		"labelText"		"13"
	}
	"recoilcontrol_label"
	{
		"labelText"		"82"
	}
	"accuraterange_label"
	{
		"labelText"		"11m"
	}
	"armorpenetration_label"
	{
		"labelText"		"115"
	}	
	"classimage"
	{
		"weaponName"		"weapon_mac10"
	}
	"select_1"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"75"		
	}
	"br_1"
	{
	    "xpos"          "81"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"234"		
	}
	"br_2"
	{
	    "xpos"          "240"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"211"		
	}
	"br_3"
	{
	    "xpos"          "217"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"50"		
	}
	"br_4"
	{
	    "xpos"          "56"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"147"		
	}
	"br_5"
	{
	    "xpos"          "153"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}