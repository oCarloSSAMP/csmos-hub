#base "base_weapon_ct.res"

"classes/m4a4_m4a1_slct.res"
{
	"weaponname_label"
	{
		"labelText"	        "M4A4 | M4A1-S"
	}
	"clipcapacity_label"
	{
		"labelText"	        "30/90 | 25/75"
	}	
	"killaward_label"
	{
		"labelText"		    "$300(150%)"
	}
	"damage_label"
	{
		"labelText"		    "33"
	}
	"firerate_label"
	{
		"labelText"	        "11 | 10"
	}
	"recoilcontrol_label"
	{
		"labelText"	        "77 | 75"
	}	
	"accuraterange_label"
	{
		"labelText"		"27m"
	}
	"armorpenetration_label"
	{
		"labelText"		"140"
	}	
	"classimage"
	{
		"weaponName"		"weapon_m4a4"
	}
	"select_2"
	{
		"visible"		"1"		
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"85"		
	}
	"br_1"
	{
	    "xpos"          "91"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"190"		
	}
	"br_2"
	{
	    "xpos"          "196"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"200"		
	}
	"br_3"
	{
	    "xpos"          "206"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"84"		
	}
	"br_4"
	{
	    "xpos"          "90"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"180"		
	}
	"br_5"
	{
	    "xpos"          "186"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
