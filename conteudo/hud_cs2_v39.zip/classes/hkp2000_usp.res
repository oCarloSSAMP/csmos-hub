#base "base_weapon_ct.res"

"classes/hkp2000_usp.res"
{
	"classimage"
	{
		"weaponName"		"weapon_hkp2000"
	}	
}
