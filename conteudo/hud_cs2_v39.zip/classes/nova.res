#base "base_weapon.res"

"classes/nova.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Nova"
	}
	"clipcapacity_label"
	{
		"labelText"		"8/32"
	}
	"killaward_label"
	{
		"labelText"		"$900(450%)"
	}
	"damage_label"
	{
		"labelText"		"26"
	}
	"firerate_label"
	{
		"labelText"		"1"
	}
	"recoilcontrol_label"
	{
		"labelText"		"0"
	}
	"accuraterange_label"
	{
		"labelText"		"3m"
	}
	"armorpenetration_label"
	{
		"labelText"		"100"
	}	
	"classimage"
	{
		"weaponName"		"weapon_nova"
	}
	"select_1"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"67"		
	}
	"br_1"
	{
	    "xpos"          "73"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"26"		
	}
	"br_2"
	{
	    "xpos"          "32"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"23"		
	}
	"br_3"
	{
	    "xpos"          "29"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"27"		
	}
	"br_4"
	{
	    "xpos"          "33"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"129"		
	}
	"br_5"
	{
	    "xpos"          "135"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}