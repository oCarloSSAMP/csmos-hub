#base "base_weapon_ct.res"

"classes/m249_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_M249"
	}
	"clipcapacity_label"
	{
		"labelText"		"100/200"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"32"
	}
	"firerate_label"
	{
		"labelText"		"12"
	}
	"recoilcontrol_label"
	{
		"labelText"		"75"
	}
	"accuraterange_label"
	{
		"labelText"		"16m"
	}
	"armorpenetration_label"
	{
		"labelText"		"160"
	}	
	"classimage"
	{
		"weaponName"		"weapon_m249"
	}
	"select_4"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"82"		
	}
	"br_1"
	{
	    "xpos"          "88"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"217"		
	}
	"br_2"
	{
	    "xpos"          "223"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"193"		
	}
	"br_3"
	{
	    "xpos"          "199"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"55"		
	}
	"br_4"
	{
	    "xpos"          "61"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"206"		
	}
	"br_5"
	{
	    "xpos"          "212"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
   "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}