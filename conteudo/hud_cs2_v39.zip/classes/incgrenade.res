#base "base_grenade_ct.res"

"classes/incgrenade.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_IncGrenade"
	}
	"weaponcost_label"
	{
		"labelText"		"$600"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_IncGrenadeDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_incgrenade"
	}
	"select_1"
	{
		"visible"		"1"	
	}	
}
