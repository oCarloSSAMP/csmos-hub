#base "base_weapon.res"

"classes/g3sg1.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_G3SG1"
	}
	"clipcapacity_label"
	{
		"labelText"		"20/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"80"
	}
	"firerate_label"
	{
		"labelText"		"4"
	}
	"recoilcontrol_label"
	{
		"labelText"		"70"
	}
	"accuraterange_label"
	{
		"labelText"		"66m"
	}
	"armorpenetration_label"
	{
		"labelText"		"164"
	}	
	"classimage"
	{
		"weaponName"		"weapon_g3sg1"
	}
	"select_6"
	{
		"visible"		"1"	
	}	
	"num_1"
	{
		"visible"		"1"
		"wide"			"206"		
	}
	"br_1"
	{
	    "xpos"          "212"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"58"		
	}
	"br_2"
	{
	    "xpos"          "64"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"180"		
	}
	"br_3"
	{
	    "xpos"          "186"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"170"		
	}
	"br_4"
	{
	    "xpos"          "176"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"212"		
	}
	"br_5"
	{
	    "xpos"          "218"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
"4"
		"visible"		"1"
		"wide"			"2"		
	}	
}