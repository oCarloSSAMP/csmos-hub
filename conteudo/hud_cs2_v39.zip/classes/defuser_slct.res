#base "base_equipment_image_ct.res"

"classes/defuser_slct.res"
{
	"classimage"
	{
		"weaponName"		"item_defuser"
	}
	"select_x_4"
	{
		"visible"		"1"	
	}	
}
}
	"select_x_4"
	{
		"visible"		"1"	
	}	
}