#base "base_weapon_ct.res"

"classes/mag7.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_MAG7"
	}
	"clipcapacity_label"
	{
		"labelText"		"5/32"
	}
	"killaward_label"
	{
		"labelText"		"$900(450%)"
	}
	"damage_label"
	{
		"labelText"		"30"
	}
	"firerate_label"
	{
		"labelText"		"1"
	}
	"recoilcontrol_label"
	{
		"labelText"		"0"
	}
	"accuraterange_label"
	{
		"labelText"		"3m"
	}
	"armorpenetration_label"
	{
		"labelText"		"150"
	}	
	"classimage"
	{
		"weaponName"		"weapon_mag7"
	}
	"select_3"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"77"		
	}
	"br_1"
	{
	    "xpos"          "83"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"28"		
	}
	"br_2"
	{
	    "xpos"          "34"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"20"		
	}
	"br_3"
	{
	    "xpos"          "26"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"23"		
	}
	"br_4"
	{
	    "xpos"          "29"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"193"		
	}
	"br_5"
	{
	    "xpos"          "199"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}