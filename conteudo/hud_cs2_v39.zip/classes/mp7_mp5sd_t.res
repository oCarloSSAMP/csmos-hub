#base "base_weapon.res"

"classes/mp7_mp5sd.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_MP7_MP5SD"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/120"
	}
	"killaward_label"
	{
		"labelText"		"$600(300%)"
	}
	"damage_label"
	{
		"labelText"		"29 | 27"
	}
	"firerate_label"
	{
		"labelText"		"12"
	}
	"recoilcontrol_label"
	{
		"labelText"		"84"
	}
	"accuraterange_label"
	{
		"labelText"		"14m"
	}
	"armorpenetration_label"
	{
		"labelText"		"124"
	}
	"StatsImage"
	{
		"ControlName"	"ImagePanel"
		"xpos"			"8"
		"ypos"			"276"
		"zpos"			"3"
		"wide"			"258"
		"tall"			"129"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/vgui/csgo_buy_stats/mp7_mp5sd"
		"scaleImage"	"1"	
	}	
	"classimage"
	{
		"weaponName"		"weapon_mp7"
	}
	"selection_image"
	{
		"ControlName"	"ImagePanel"
		"xpos"			"0"
		"ypos"			"2"
		"zpos"			"2"
		"wide"			"275"
		"tall"			"275"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/vgui/hud_buy_select/select_2"
		"scaleImage"	"1"		
	}	
}
