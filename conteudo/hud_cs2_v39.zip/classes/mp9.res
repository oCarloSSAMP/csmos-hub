#base "base_weapon_ct.res"

"classes/mp9.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_MP9"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/120"
	}
	"killaward_label"
	{
		"labelText"		"$600(300%)"
	}
	"damage_label"
	{
		"labelText"		"26"
	}
	"firerate_label"
	{
		"labelText"		"14"
	}
	"recoilcontrol_label"
	{
		"labelText"		"81"
	}
	"accuraterange_label"
	{
		"labelText"		"16m"
	}
	"armorpenetration_label"
	{
		"labelText"		"120"
	}	
	"classimage"
	{
		"weaponName"		"weapon_mp9"
	}
	"select_1"
	{
		"visible"		"1"		
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"67"		
	}
	"br_1"
	{
	    "xpos"          "73"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_2"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"209"		
	}
	"br_3"
	{
	    "xpos"          "215"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"74"		
	}
	"br_4"
	{
	    "xpos"          "80"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"155"		
	}
	"br_5"
	{
	    "xpos"          "161"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}

		"visible"		"1"
		"wide"			"2"		
	}	
}