#base "base_weapon.res"

"classes/deserteagle.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_DesertEagleRevolver"
	}
	"clipcapacity_label"
	{
		"labelText"		"7/35 | 8/8"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"63"
	}
	"firerate_label"
	{
		"labelText"		"4"
	}
	"recoilcontrol_label"
	{
		"labelText"		"52"
	}
	"accuraterange_label"
	{
		"labelText"		"24m"
	}
	"armorpenetration_label"
	{
		"labelText"		"186"
	}
	"StatsImage"
	{
		"ControlName"	"ImagePanel"
		"xpos"			"8"
		"ypos"			"276"
		"zpos"			"3"
		"wide"			"258"
		"tall"			"129"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/vgui/csgo_buy_stats/deagle"
		"scaleImage"	"1"	
	}
	"classimage"
	{
		"weaponName"		"weapon_deagle"
	}
	"MainImage"
	{
		"ControlName"	"ImagePanel"
		"xpos"			"0"
		"ypos"			"2"
		"zpos"			"2"
		"wide"			"275"
		"tall"			"275"
		"visible"		"1"
		"enabled"		"1"
		"image"			"gfx/vgui/hud_buy_select/select_5"
		"scaleImage"	"1"		
	}	
}
