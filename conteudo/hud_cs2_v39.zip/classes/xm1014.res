#base "base_weapon.res"

"classes/xm1014.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_xm1014"
	}
	"clipcapacity_label"
	{
		"labelText"		"7/32"
	}
	"killaward_label"
	{
		"labelText"		"$900(450%)"
	}
	"damage_label"
	{
		"labelText"		"20"
	}
	"firerate_label"
	{
		"labelText"		"3"
	}
	"recoilcontrol_label"
	{
		"labelText"		"20"
	}
	"accuraterange_label"
	{
		"labelText"		"3m"
	}
	"armorpenetration_label"
	{
		"labelText"		"160"
	}	
	"classimage"
	{
		"weaponName"		"weapon_xm1014"
	}
	"select_2"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"51"		
	}
	"br_1"
	{
	    "xpos"          "57"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"48"		
	}
	"br_2"
	{
	    "xpos"          "54"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"51"		
	}
	"br_3"
	{
	    "xpos"          "57"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"29"		
	}
	"br_4"
	{
	    "xpos"          "35"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"206"		
	}
	"br_5"
	{
	    "xpos"          "212"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}