#base "base_weapon_ct.res"

"classes/p250_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_P250"
	}
	"clipcapacity_label"
	{
		"labelText"		"13/26"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"38"
	}
	"firerate_label"
	{
		"labelText"		"6"
	}
	"recoilcontrol_label"
	{
		"labelText"		"74"
	}
	"accuraterange_label"
	{
		"labelText"		"13m"
	}
	"armorpenetration_label"
	{
		"labelText"		"128"
	}	
	"classimage"
	{
		"weaponName"		"weapon_p250"
	}
	"select_3"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"98"		
	}
	"br_1"
	{
	    "xpos"          "104"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}		
	"num_2"
	{
		"visible"		"1"
		"wide"			"107"		
	}
	"br_2"
	{
	    "xpos"          "113"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}		
	"num_3"
	{
		"visible"		"1"
		"wide"			"190"		
	}
	"br_3"
	{
	    "xpos"          "196"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}		
	"num_4"
	{
		"visible"		"1"
		"wide"			"58"		
	}
	"br_4"
	{
	    "xpos"          "64"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}		
	"num_5"
	{
		"visible"		"1"
		"wide"			"165"		
	}
	"br_5"
	{
	    "xpos"          "171"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}