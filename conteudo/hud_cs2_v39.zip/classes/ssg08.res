#base "base_weapon.res"

"classes/ssg08.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_SSG08"
	}
	"clipcapacity_label"
	{
		"labelText"		"10/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"88"
	}
	"firerate_label"
	{
		"labelText"		"0.8"
	}
	"recoilcontrol_label"
	{
		"labelText"		"67"
	}
	"accuraterange_label"
	{
		"labelText"		"47m"
	}
	"armorpenetration_label"
	{
		"labelText"		"170"
	}	
	"classimage"
	{
		"weaponName"		"weapon_ssg08"
	}
	"select_3"
	{
		"visible"		"1"	
	}	
	"num_1"
	{
		"visible"		"1"
		"wide"			"227"		
	}
	"br_1"
	{
	    "xpos"          "233"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"31"		
	}
	"br_2"
	{
	    "xpos"          "37"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"173"		
	}
	"br_3"
	{
	    "xpos"          "179"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"161"		
	}
	"br_4"
	{
	    "xpos"          "167"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"219"		
	}
	"br_5"
	{
	    "xpos"          "225"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}
}