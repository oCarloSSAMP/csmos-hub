#base "base_grenade_ct.res"

"classes/flashbang_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Flashbang"
	}
	"weaponcost_label"
	{
		"labelText"		"$200"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_FlashbangDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_flashbang"
	}
	"select_3"
	{
		"visible"		"1"		
	}	
}

	"select_3"
	{
		"visible"		"1"		
	}	
}