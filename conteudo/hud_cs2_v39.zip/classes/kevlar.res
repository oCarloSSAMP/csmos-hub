#base "base_equipment_image.res"

"classes/kevlar.res"
{ 
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Kevlar"
	}
	"weaponcost_label"
	{
		"labelText"		"$650"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_KevlarDescription"
	}
	"number_3"
	{
		"labelText"		"3"
	}	
	"classimage"
	{
		"weaponName"		"item_kevlar"
	}
	"select_x_1"
	{
		"visible"		"1"	
	}	
}
		"1"	
	}	
}