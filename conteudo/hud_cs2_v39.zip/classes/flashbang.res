#base "base_grenade.res"

"classes/flashbang.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Flashbang"
	}
	"weaponcost_label"
	{
		"labelText"		"$200"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_FlashbangDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_flashbang"
	}
	"select_3"
	{
		"visible"		"1"	
	}	
}
}
	"select_3"
	{
		"visible"		"1"	
	}	
}