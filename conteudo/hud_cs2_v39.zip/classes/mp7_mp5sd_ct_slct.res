#base "base_weapon_ct.res"

"classes/mp7_mp5sd_ct_slct.res"
{
	"weaponname_label"
	{
        "labelText"	    "MP5-SD | MP7"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/120"
	}
	"killaward_label"
	{
		"labelText"		"$600(300%)"
	}
	"damage_label"
	{
		"labelText"		"29 | 27"
	}
	"firerate_label"
	{
		"labelText"		"12"
	}
	"recoilcontrol_label"
	{
		"labelText"		"84"
	}
	"accuraterange_label"
	{
		"labelText"		"14m"
	}
	"armorpenetration_label"
	{
		"labelText"		"124"
	}	
	"classimage"
	{
		"weaponName"		"weapon_mp5sd"
	}
	"select_2"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"72"		
	}
	"br_1"
	{
	    "xpos"          "78"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"215"		
	}
	"br_2"
	{
	    "xpos"          "221"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"217"		
	}
	"br_3"
	{
	    "xpos"          "223"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"54"		
	}
	"br_4"
	{
	    "xpos"          "60"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"161"		
	}
	"br_5"
	{
	    "xpos"          "167"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}
}
