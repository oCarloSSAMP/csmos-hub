#base "base_weapon_ct.res"

"classes/elites_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Elites"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/120"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"38"
	}
	"firerate_label"
	{
		"labelText"		"8"
	}
	"recoilcontrol_label"
	{
		"labelText"		"73"
	}
	"accuraterange_label"
	{
		"labelText"		"17m"
	}
	"armorpenetration_label"
	{
		"labelText"		"115"
	}	
	"classimage"
	{
		"weaponName"		"weapon_elite"
	}
	"select_2"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"98"		
	}
	"br_1"
	{
	    "xpos"          "104"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"116"		
	}
	"br_2"
	{
	    "xpos"          "122"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"188"		
	}
	"br_3"
	{
	    "xpos"          "194"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"44"		
	}
	"br_4"
	{
	    "xpos"          "50"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"147"		
	}
	"br_5"
	{
	    "xpos"          "153"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}