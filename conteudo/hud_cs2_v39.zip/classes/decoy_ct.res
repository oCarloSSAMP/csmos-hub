#base "base_grenade_ct.res"

"classes/decoy_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Decoy"
	}
	"weaponcost_label"
	{
		"labelText"		"$50"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_DecoyDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_decoy"
	}
	"select_2"
	{
		"visible"		"1"		
	}		
}

	"select_2"
	{
		"visible"		"1"		
	}		
}