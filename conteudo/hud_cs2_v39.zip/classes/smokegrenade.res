#base "base_grenade.res"

"classes/smokegrenade.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Smoke_Grenade"
	}
	"weaponcost_label"
	{
		"labelText"		"$300"
	}
	"item_description"
	{
		"labelText"		"#Cstrike_SmokeGrenadeDescription"
	}	
	"classimage"
	{
		"weaponName"		"weapon_smokegrenade"
	}
	"select_5"
	{
		"visible"		"1"		
	}	
}

	"select_5"
	{
		"visible"		"1"		
	}	
}