
"classes/base_weapon_taser_ct.res"
{

	"classimage"
	{
		"ControlName"	"CSBuyMenuImagePanel"
		"fieldName"		"classimage"
		"xpos"			"225"
		"ypos"			"-10"
		"wide"			"300"
		"tall"			"440"
		"autoResize"	"0"
		"pinCorner"		"0"
		"visible"		"1"
		"enabled"		"1"
		"scaleImage"	"1"
		"3DModel"		"models/weapons/w_pist_glock18.mdl"
		"AnimName"		"UI_BuyMenu_pistol"
		"view_xpos"		"-92"
		"view_ypos"		"-10"
		"view_zpos"		"55"
		"zpos"			"1"		
	}	
	"stats_base"
	{
		"visible"		"1"
	}	
}