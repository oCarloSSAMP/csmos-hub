#base "base_weapon_ct.res"

"classes/famas.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Famas"
	}
	"clipcapacity_label"
	{
		"labelText"		"25/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"30"
	}
	"firerate_label"
	{
		"labelText"		"11"
	}
	"recoilcontrol_label"
	{
		"labelText"		"80"
	}
	"accuraterange_label"
	{
		"labelText"		"14m"
	}
	"armorpenetration_label"
	{
		"labelText"		"140"
	}	
	"classimage"
	{
		"weaponName"		"weapon_famas"
	}
	"select_1"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"77"		
	}
	"br_1"
	{
	    "xpos"          "83"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"188"		
	}
	"br_2"
	{
	    "xpos"          "194"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"206"		
	}
	"br_3"
	{
	    "xpos"          "212"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"36"		
	}
	"br_4"
	{
	    "xpos"          "42"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"180"		
	}
	"br_5"
	{
	    "xpos"          "186"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}