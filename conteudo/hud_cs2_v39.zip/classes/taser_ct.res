#base "base_weapon_taser_ct.res"

"classes/taser_ct.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Taser"
	}
	"clipcapacity_label"
	{
		"labelText"		"1/0"
	}
	"killaward_label"
	{
		"labelText"		"$0(0%)"
	}
	"damage_label"
	{
		"labelText"		"500"
	}
	"firerate_label"
	{
		"labelText"		"6"
	}
	"recoilcontrol_label"
	{
		"labelText"		"106"
	}
	"accuraterange_label"
	{
		"labelText"		"56m"
	}
	"armorpenetration_label"
	{
		"labelText"		"200"
	}	
	"classimage"
	{
		"weaponName"		"weapon_taser"
	}
	"select_x_3"
	{
		"visible"		"1"		
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_1"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"110"		
	}
	"br_2"
	{
	    "xpos"          "116"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_3"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"184"		
	}
	"br_4"
	{
	    "xpos"          "190"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"258"		
	}
	"br_5"
	{
	    "xpos"          "264"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}
}
 "4"
		"visible"		"1"
		"wide"			"2"		
	}
}