#base "base_weapon_ct.res"

"classes/hkp2000_usp_slct.res"
{
	"weaponname_label"
	{
		"labelText"	            "HKP2000 | USP-S"
	}
	"clipcapacity_label"
	{
		"labelText"  	        "13/52 | 12/24"
	}	
	"killaward_label"
	{
		"labelText"	        	"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		        "35"
	}
	"firerate_label"
	{
		"labelText"		        "6"
	}
	"recoilcontrol_label"
	{
		"labelText"	            "74 | 71"
	}
	"accuraterange_label"
	{
		"labelText"             "22m | 20m"
	}	
	"armorpenetration_label"
	{
		"labelText"		"100"
	}	
	"classimage"
	{
		"weaponName"		"weapon_usp_silencer"
	}
	"select_1"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"90"		
	}
	"br_1"
	{
	    "xpos"          "96"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"114"		
	}
	"br_2"
	{
	    "xpos"          "120"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"188"		
	}
	"br_3"
	{
	    "xpos"          "194"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"54"		
	}
	"br_4"
	{
	    "xpos"          "60"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"129"		
	}
	"br_5"
	{
	    "xpos"          "135"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
