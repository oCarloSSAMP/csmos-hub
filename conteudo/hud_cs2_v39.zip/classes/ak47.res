#base "base_weapon.res"

"classes/ak47.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_AK47"
	}
	"clipcapacity_label"
	{
		"labelText"		"30/90"
	}
	"killaward_label"
	{
		"labelText"		"$300(150%)"
	}
	"damage_label"
	{
		"labelText"		"36"
	}
	"firerate_label"
	{
		"labelText"		"10"
	}
	"recoilcontrol_label"
	{
		"labelText"		"60"
	}
	"accuraterange_label"
	{
		"labelText"		"22m"
	}
	"armorpenetration_label"
	{
		"labelText"		"154"
	}	
	"classimage"
	{
		"weaponName"		"weapon_ak47"
	}
	"select_2"
	{
		"visible"		"1"
	}	
	"num_1"
	{
		"visible"		"1"
		"wide"			"93"		
	}
	"br_1"
	{
	    "xpos"          "99"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"169"		
	}
	"br_2"
	{
	    "xpos"          "175"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"155"		
	}
	"br_3"
	{
	    "xpos"          "161"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"97"		
	}
	"br_4"
	{
	    "xpos"          "103"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"199"
	}
	"br_5"
	{
	    "xpos"          "205"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"
	}	
}
