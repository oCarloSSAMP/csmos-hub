#base "base_weapon.res"

"classes/bizon.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_Bizon"
	}
	"clipcapacity_label"
	{
		"labelText"		"64/120"
	}
	"killaward_label"
	{
		"labelText"		"$600(300%)"
	}
	"damage_label"
	{
		"labelText"		"27"
	}
	"firerate_label"
	{
		"labelText"		"12"
	}
	"recoilcontrol_label"
	{
		"labelText"		"82"
	}
	"accuraterange_label"
	{
		"labelText"		"10m"
	}
	"armorpenetration_label"
	{
		"labelText"		"126"
	}	
	"classimage"
	{
		"weaponName"		"weapon_bizon"
	}
	"select_5"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"70"		
	}
	"br_1"
	{
	    "xpos"          "76"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"207"		
	}
	"br_2"
	{
	    "xpos"          "213"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"211"		
	}
	"br_3"
	{
	    "xpos"          "217"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"26"		
	}
	"br_4"
	{
	    "xpos"          "32"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"162"		
	}
	"br_5"
	{
	    "xpos"          "168"
	    "zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
