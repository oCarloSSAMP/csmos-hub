#base "base_equipment_image_ct.res"

"classes/defuser.res"
{

}