#base "base_weapon.res"

"classes/sawedoff.res"
{
	"weaponname_label"
	{
		"labelText"		"#Cstrike_SawedOff"
	}
	"clipcapacity_label"
	{
		"labelText"		"7/32"
	}
	"killaward_label"
	{
		"labelText"		"$900(450%)"
	}
	"damage_label"
	{
		"labelText"		"32"
	}
	"firerate_label"
	{
		"labelText"		"1"
	}
	"recoilcontrol_label"
	{
		"labelText"		"0"
	}
	"accuraterange_label"
	{
		"labelText"		"2m"
	}
	"armorpenetration_label"
	{
		"labelText"		"150"
	}	
	"classimage"
	{
		"weaponName"		"weapon_sawedoff"
	}
	"select_3"
	{
		"visible"		"1"	
	}
	"num_1"
	{
		"visible"		"1"
		"wide"			"82"		
	}
	"br_1"
	{
	    "xpos"          "88"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_2"
	{
		"visible"		"1"
		"wide"			"35"		
	}
	"br_2"
	{
	    "xpos"          "41"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_3"
	{
		"visible"		"1"
		"wide"			"21"		
	}
	"br_3"
	{
	    "xpos"          "27"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_4"
	{
		"visible"		"1"
		"wide"			"25"		
	}
	"br_4"
	{
	    "xpos"          "31"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
	"num_5"
	{
		"visible"		"1"
		"wide"			"193"		
	}
	"br_5"
	{
	    "xpos"          "199"
		"zpos"          "4"
		"visible"		"1"
		"wide"			"2"		
	}	
}
4"
		"visible"		"1"
		"wide"			"2"		
	}	
}