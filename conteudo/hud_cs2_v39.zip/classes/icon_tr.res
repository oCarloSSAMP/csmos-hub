"classes/icon_tr.res"
{
	"tr_icon" 
	{
		"ControlName"	"ImagePanel"
		"xpos"			"3"
		"ypos"			"2"
		"zpos"			"3"
		"wide"			"273"
		"tall"			"273"
		"visible"       "1"
		"enabled"       "1"
		"image"			"gfx/vgui/csgo_buy_menu/tr_icon"
		"scaleImage"	"1"	
	}	
}