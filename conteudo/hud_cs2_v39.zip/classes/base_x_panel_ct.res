#base "x_panel.res"

"classes/base_x_panel_ct.res"
{
	"ct_icon" 
	{
		"ControlName"	"ImagePanel"
		"xpos"			"0"
		"ypos"			"2"
		"zpos"			"3"
		"wide"			"275"
		"tall"			"275"
		"visible"       "1"
		"enabled"       "1"
		"image"			"gfx/vgui/csgo_buy_menu/ct_icon"
		"scaleImage"	"1"	
	}	
}