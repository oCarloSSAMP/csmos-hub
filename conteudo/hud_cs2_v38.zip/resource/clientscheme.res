#base "hudcolor.res"

Scheme
{
	Colors
	{
		// base colors	
	    "BuyMenuClassNames"       "245 245 245 255"
	    "BuyMenuNumbersColor"     "255 255 255 055"
		"BuyMenuIconColor"        "210 210 210 255"
		"Orange"		          "255 176 0 255"
		"OrangeDim"		          "255 176 0 120"
		"LightOrange"		      "188 112 0 128"
			
		"Red"				"255 255 255 225"
		"Black"				"0 0 0 255"
		"TransparentBlack"	"0 0 0 196"
		"TransparentLightBlack"	"0 0 0 90"
		"RoundWinPanelBackground" "0 0 0 179"

		"C4Color"										"255 0 0 198" 
		"C4FlashColor"									"255 0 0 244" 

		"Blank"				"0 0 0 0"
		"ForTesting"		"255 0 0 32"
		"ForTesting_Magenta"	"255 0 255 255"
		"ForTesting_MagentaDim"	"255 0 255 120"
		
		//These were ripped from SourceScheme
		"SteamLightGreen"	"157 194 80 255"
		"AchievementsLightGrey"		"79 79 79 255"
		"White"				"255 255 255 255"
		"Blank"											"000 000 000 000"	
		
		"TheHudColorLmfao"			"255 207 112 200"
		"unselected_weapon_clr"			"255 200 87 255"
		"selected_weapon_clr"			"255 207 112 200"
		"Circle"       "255 207 112 200"

		"ScoreboardCT"		"150 200 255 255"
		"ScoreboardT"			"240 90 90 255"
		"ScoreboardDead"		"125 125 125 255"
		"ScoreboardClanCT"	"150 200 255 255"
		"ScoreboardClanT"		"240 90 90 255"
		"ScoreboardClanDead"	"125 125 125 255"
		
		"TeamCT"				"181 212 238 255"
		"TeamCTSpectator"		"90 184 244 255"
		"TeamCTDark"			"111 156 230 255"
		"TeamT"				"234 209 138 255"
		"TeamTSpectator"		"240 201 65 255"
		"TeamTDark"			"234 190 84 255"
    
	}

	BaseSettings 
	
	{
		Border.Bright					"0 0 0 0"
		Border.Dark						"0 0 0 0"
		Border.Selection				"0 0 0 0"
		Border.BuyPreset				"255 255 255 255"

		Button.TextColor				"White"
		Button.BgColor					"000 000 000 000"
		Button.ArmedTextColor			"200 200 200 255"
		Button.ArmedBgColor				"000 000 000 000"
		Button.DepressedTextColor		"White"
		Button.DepressedBgColor			"000 000 255 000"

		CheckButton.TextColor			"White"
		CheckButton.SelectedTextColor	"000 000 255 255"
		CheckButton.BgColor				"000 000 000 000"
		CheckButton.Border1  			"000 000 000 000" 		
		CheckButton.Border2  			"000 000 000 000"		
		CheckButton.Check				"000 000 255 255"				

		ComboBoxButton.ArrowColor		"White"
		ComboBoxButton.ArmedArrowColor	"White"
		ComboBoxButton.BgColor			"000 000 000 000"
		ComboBoxButton.DisabledBgColor	"000 000 000 000"

		Frame.BgColor					"000 000 000 000"
		Frame.OutOfFocusBgColor			"000 000 000 000"
		Frame.FocusTransitionEffectTime	"0.0"// time it takes for a window to fade in/out on focus/out of focus	
		Frame.TransitionEffectTime		"0.0"// time it takes for a window to fade in/out on open/close
		Frame.AutoSnapRange				"0"
		FrameGrip.Color1				"Blank"
		FrameGrip.Color2				"Blank"
		FrameTitleButton.FgColor		"Blank"
		FrameTitleButton.BgColor		"Blank"
		FrameTitleButton.DisabledFgColor	"Blank"
		FrameTitleButton.DisabledBgColor	"Blank"
		FrameSystemButton.FgColor		"Blank"
		FrameSystemButton.BgColor		"Blank"
		FrameSystemButton.Icon			"000 000 000 000"
		FrameSystemButton.DisabledIcon	"000 000 000 000"
		FrameTitleBar.TextColor			"255 000 000 255"
		FrameTitleBar.BgColor			"Blank"
		FrameTitleBar.DisabledTextColor	"White"
		FrameTitleBar.DisabledBgColor	"Blank"

		GraphPanel.FgColor				"000 000 000 000"
		GraphPanel.BgColor				"000 000 000 000"

		Label.TextDullColor				"White"
		Label.TextColor					"BuyMenuIconColor"
		Label.TextBrightColor			"White"
		Label.SelectedTextColor			"000 000 255 255"
		Label.BgColor					"000 000 000 000"
		Label.DisabledFgColor1			"Blank"
		Label.DisabledFgColor2			"LightWhite"
	
		ListPanel.TextColor					"White"
		ListPanel.BgColor					"000 000 000 000"
		ListPanel.SelectedTextColor			"Black"
		ListPanel.SelectedBgColor			"Red"
		ListPanel.SelectedOutOfFocusBgColor "Red"
		ListPanel.EmptyListInfoTextColor	"White"

		Menu.TextColor					"White"
		Menu.BgColor					"000 000 000 000"
		Menu.ArmedTextColor				"000 000 255 255"
		Menu.ArmedBgColor				"200 200 200 255"
		Menu.TextInset					"6"

		Chat.TypingText					"255 255 255 255"

		Panel.FgColor					"HudColor"
		Panel.BgColor					"000 000 000 000"

		HTML.BgColor					"000 000 000 000"

		"BuyPreset.BgColor"				"0 0 0 128"
		"BuyPresetListBox.BgColor"			"0 0 0 128"
		"Popup.BgColor"					"0 0 0 230"
		
		ProgressBar.FgColor				"White"
		ProgressBar.BgColor				"TransparentBlack"		

		PropertySheet.TextColor			"White"
		PropertySheet.SelectedTextColor	"000 000 255 255"
		PropertySheet.TransitionEffectTime	"0.25"	// time to change from one tab to another

		RadioButton.TextColor			"White"
		RadioButton.SelectedTextColor	"White"

		RichText.TextColor				"White"
		RichText.BgColor				"Blank"
		RichText.SelectedTextColor		"000 000 255 255"
		RichText.SelectedBgColor		"Red"

		ScrollBarButton.FgColor				"White"
		ScrollBarButton.BgColor				"Blank"
		ScrollBarButton.ArmedFgColor		"White"
		ScrollBarButton.ArmedBgColor		"Blank"
		ScrollBarButton.DepressedFgColor	"White"
		ScrollBarButton.DepressedBgColor	"Blank"

		ScrollBarSlider.FgColor				"Blank"
		ScrollBarSlider.BgColor				"Blank"

		SectionedListPanel.HeaderTextColor	"White"
		SectionedListPanel.HeaderBgColor	"Blank"
		SectionedListPanel.DividerColor		"Black"
		SectionedListPanel.TextColor		"White"
		SectionedListPanel.BrightTextColor	"White"
		SectionedListPanel.BgColor			"000 000 000 000"
		SectionedListPanel.SelectedTextColor            "Black"
		SectionedListPanel.SelectedBgColor	            "Red"
		SectionedListPanel.OutOfFocusSelectedTextColor	"Black"
		SectionedListPanel.OutOfFocusSelectedBgColor	"255 255 255 32"

		Slider.NobColor				"108 108 108 255"
		Slider.TextColor			"White"
		Slider.TrackColor		    "31 31 31 255"
		Slider.DisabledTextColor1   "117 117 117 255"
		Slider.DisabledTextColor2	"30 30 30 255"

		TextEntry.TextColor			"White"
		TextEntry.BgColor			"000 000 000 000"
		TextEntry.CursorColor		"White"
		TextEntry.DisabledTextColor	"White"
		TextEntry.DisabledBgColor	"Blank"
		TextEntry.SelectedTextColor	"Black"
		TextEntry.SelectedBgColor	"Red"
		TextEntry.OutOfFocusSelectedBgColor	"Red"
		TextEntry.FocusEdgeColor	"000 000 000 000"

		ToggleButton.SelectedTextColor	"White"

		Tooltip.TextColor			"TransparentBlack"
		Tooltip.BgColor				"Red"

		TreeView.BgColor			"000 000 000 000"

		WizardSubPanel.BgColor		"Blank"


		// scheme-specific colors
		"FgColor"			"White"
		"BgColor"			"000 000 000 000"

		"ViewportBG"		"Blank"
		"team0"				"204 204 204 255" 
		"team1"				"118 192 245 255"         
		"team2"				"250 50 000 255" 	  

		"MapDescriptionText" "White" 		  
		"CT_Blue"			"181 211 235 255"
		"T_Red"				"209 189 128 255"
		"Hostage_Yellow"	"255 255 0 255"
		"HudIcon_Green"		"0 160 0 255"
		"HudIcon_Red"		"255 0 0 255"
		"Health_Critical"   "240 0 0 255"


		// CHudMenu
		"ItemColor"		"White"	// default 255 167 42 255
		"MenuColor"		"White"
		"MenuBoxBg"		"0 0 0 100"
        
        // buy menu colors
        "BuyMenu.AvailableColor"    "TheHudcolorLmfao"
		"BuyMenu.UnavailableColor"  "215 0 0 255"
		"BuyMenu.AlreadyOwnColor"   "100 100 100 255"

		// weapon selection colors
		"SelectionNumberFg"		"255 220 0 200"
		"SelectionTextFg"		"255 220 0 200"
		"SelectionEmptyBoxBg" 	"0 0 0 80"
		"SelectionBoxBg" 		"0 0 0 80"
		"SelectionSelectedBoxBg" "0 0 0 190"

		// Hint message colors
		"HintMessageFg"			"255 255 255 0"
		"HintMessageBg" 		"0 0 0 0"

		"ProgressBarFg"			"White"

		// Top-left corner of the "Counter-Strike" on the main screen
		"Main.Title1.X"		"32"
		"Main.Title1.Y"		"0"
		"Main.Title1.Color"	"255 255 255 0"

		// Top-left corner of the "SOURCE" on the main screen
		"Main.Title2.X"		"380"
		"Main.Title2.Y"		"30"
		"Main.Title2.Color"	"255 255 255 0"

		// Top-left corner of the "BETA" on the main screen
		"Main.Title3.X"		"460"
		"Main.Title3.Y"		"-10"
		"Main.Title3.Color"	"255 255 0 255"

		// Top-left corner of the menu on the main screen
		"Main.Menu.X"		"8"
		"Main.Menu.Y"		"10"

		// Blank space to leave beneath the menu on the main screen
		"Main.BottomBorder"	"0"
	}
	Fonts
	{

		
		ClientTitleFont
		{
			"1"
			{
				"name"  "Counter-Strike Logo" // CSlogo.ttf
				"tall"  "60"
				"weight" "0"
				"additive" "0"
				"antialias" "1"
			}
		}
		"BuyMenuItems"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"500"
				"antialias" "1"
			}
		}
		"BuyMenuItems2"
		{
			"1"
			{
				"name"		"Stratum2 Bold"
				"tall"		"16"
				"weight"	"500"
				"antialias" "1"
			}
		}
		"MenuSmallMod"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"8" 
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"1"
			}
		}

		"TeamMenuFont"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"16"
				"weight"	"600"
				"antialias" "1"
				"outline"	"0"
				"additive"  "0"
			}
		}
		"TeamMenuFont2"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"500"
				"antialias" "1"
				"outline"	"0"
			}
		}
		"StartIcons"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"700"
				"antialias" "1"
				"outline"	"0"
			}
		}		
		"WinLabelNew"
		{
			"1"
			{
				"name"		"WinPanelLabel"
				"tall"		"18"
				"weight"	"500"
				"antialias" "1"
				"outline"	"1"
			}
		}
		"Spectate"
		{
			"1"
			{
				"name"		"cstrike_icons" // Cstrike.ttf //"Spectate"
				"tall"		"36"
				"weight"	"500"
				"antialias" "1"
				"outline"	"1"
			}
		}
		WinPanel
		{
			"1"
			{
				"name"		"StratumNo2Black" //NotoSans-Bold.ttf
				"tall"		"15"
				"weight"	"700"
				"antialias" "1"
			
			}
		}
		WinPanelMvp
		{
			"1"
			{
				"name"		"StratumNo2" //NotoSans-Bold.ttf
				"tall"		"12"
				"weight"	"700"
				"antialias" "1"
				"outline"   "0"
                "dropshadow" "1" 				
			
			}
		}		
		WinPanelDescription
		{
			"1"
			{
				"name"		"StratumNo2" //NotoSans-Bold.ttf
				"tall"		"10"
				"weight"	"700"
				"antialias" "1"
				"outline"   "0" 
				"dropshadow" "1" 
         }
      }
			"harga"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"11"
				"weight"		"0"
				"additive"		"1"
				"antialias"	"1"
				"custom"		"1" [$OSX]
   }
 }
 "RIFLESFont"
		{
			"1"
			{
				"name"		"RIFLES"
				"tall"		"38"
				"weight"		"0"
				"additive"		"1"
				"antialias"	"1"
				"custom"		"1" [$OSX]
  }
}
 "RIFLESFont1"
		{
			"1"
			{
				"name"		"GMCX_ICO1"
				"tall"		"38"
				"weight"		"0"
				"additive"		"1"
				"antialias"	"1"
				"custom"		"1" [$OSX]
      }
}
     "RIFLESFont2"
		{
			"1"
			{
				"name"		"RIFLES"
				"tall"		"30"
				"weight"		"0"
				"additive"		"1"
				"antialias"	"1"
				"custom"		"1" [$OSX]
    }
}
  "ICONIC"
		{
			"1"
			{
				"name"		"TEST1"
				"tall"		"500"
				"weight"		"0"
				"additive"		"1"
				"antialias"	"1"
				"custom"		"1" [$OSX]
			}
		}	

  "circle"
		{
			"1"
			{
				"name"		"TEST1"
				"tall"		"38"
				"weight"		"0"
				"additive"		"0"
				"antialias"	"1"
				"custom"		"1" [$OSX]
			}
   }
"card"
		{
			"1"
			{
				"name"		"TEST1"
				"tall"		"50"
				"weight"		"0"
				"additive"		"0"
				"antialias"	"1"
				"custom"		"1" [$OSX]
			}
   }
		"Default"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"900"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
				"antialias"	"1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"900"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
				"antialias"	"1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"15"
				"weight"	"900"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"900"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"900"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"range" 		"0x0000 0x00FF"
				"weight"		"900"
				"antialias"	"1"
			}
			"7"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"range" 		"0x0000 0x00FF"
				"weight"		"800"
				"antialias"	"1"
			}
		}
		"DefaultBig"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"15"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"19"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"26"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"30"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"18"
				"range" 		"0x0000 0x00FF"
				"weight"		"900"
			}
		}
		"DefaultLarge"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"18"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"23"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"31"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"36"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"22"
				"range" 		"0x0000 0x00FF"
				"weight"		"900"
			}
		}
		
		"DefaultLarger"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"19"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"31"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"41"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"48"
				"weight"	"1100"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"22"
				"range" 		"0x0000 0x00FF"
				"weight"		"900"
			}
		}
		
		"DefaultVeryLarge"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"22"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"28"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"36"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"48"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"56"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"28"
				"range" 		"0x0000 0x00FF"
				"weight"		"900"
			}
		}
		
		"DefaultGigantic"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"34"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"42"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"54"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"64"
				"weight"	"1300"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"32"
				"range" 		"0x0000 0x00FF"
				"weight"		"900"
			}
		}
		
		"StratumSmall"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"8"
				"weight"	"0"
				"antialias"	"1"
				"unlimited"	"1"
				"custom"	"1"
			}
		}
		"StratumMedium"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"10"
				"antialias"	"1"
				"unlimited"	"1"
				"custom"	"1"
			}
		}
		"StratumWide"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"10"
				"antialias"	"1"
				"unlimited"	"1"
				"custom"	"1"
			}
		}	
		
		"UiHeadline"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
			}
		}			
		"DefaultUnderline"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"500"
				"underline" "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"11"
				"range" 		"0x0000 0x00FF"
				"weight"		"800"
			}
		}
		"DefaultSmall"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"480 599"
				"antialias"	"1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"600 767"
				"antialias"	"1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"15"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"range" 		"0x0000 0x00FF"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"CSUnderline"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"480 599"
				"underline" "1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"600 767"
				"underline" "1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"768 1023"
				"antialias"	"1"
				"underline" "1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"1024 1199"
				"antialias"	"1"
				"underline" "1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"0"
				"range"		"0x0000 0x017F"
				"yres"	"1200 6000"
				"antialias"	"1"
				"underline" "1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"range" 		"0x0000 0x00FF"
				"weight"		"0"
				"underline" "1"
			}
		}
		"DefaultVerySmall"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"15"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"768 1023"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1024 1199"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"	"1200 6000"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"range" 		"0x0000 0x00FF"
				"weight"		"0"
			}
			"7"
			{
				"name"		"StratumNo2"
				"tall"		"11"
				"range" 		"0x0000 0x00FF"
				"weight"		"0"
			}
		}
		CenterPrintText
		{
			// note that this scales with the screen resolution
			"1"
			{
				"name"		"Trebuchet MS" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"18"
				"weight"	"900"
				"antialias" "1"
				"additive"	"1"
			}
		}		
		HudHintText
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"700"
				"yres"	"480 599"
				"antialias"		"1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"700"
				"yres"	"600 767"
				"antialias"		"1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"700"
				"yres"	"768 1023"
				"antialias"		"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"700"
				"yres"	"1024 1199"
				"antialias"		"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"700"
				"yres"	"1200 10000"
				"antialias"		"1"
			}
		}
		"HeadName"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		HudSelectionNumbers
		{
			"1"
			{
				"name"			"StratumNo2Black"
				"tall"			"11"
				"weight"		"700"
				"antialias"		"1"
				"additive"		"1"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}

		HudSelectionText
		{
			"1"
			{
				"name"			"StratumNo2"
				"tall"			"20"
				"weight"		"700"
				"antialias" 	"1"
				"yres"			"1 599"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"additive"		"1"
				"dropshadow"	"0"
				"outline" 		"1"
			}
			"2"
			{
				"name"			"StratumNo2"
				"tall"			"20"
				"weight"		"700"
				"antialias"		 "1"
				"yres"			"600 767"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"additive"		"1"
				"dropshadow"	"0"
				"outline" 		"1"
			}
			"3"
			{
				"name"			"StratumNo2"
				"tall"			"20"
				"weight"		"900"
				"antialias"		 "1"
				"yres"			"768 1023"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"dropshadow"	"0"
				"outline" 		"1"
			}
			"4"
			{
				"name"			"StratumNo2"
				"tall"			"20"
				"weight"		"900"
				"antialias" 	"1"
				"yres"			"1024 1199"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"dropshadow"	"0"
				"outline" 		"1"
			}
			"5"
			{
				"name"			"StratumNo2"
				"tall"			"20"
				"weight"		"1000"
				"antialias" 	"1"
				"yres"			"1200 10000"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"dropshadow"	"0"
				"outline" 		"1"
			}
		}

		BudgetLabel
		{
			"1"
			{
				"name"			"Courier New"
				"tall"			"14"
				"weight"		"400"
				"outline"		"1"
				"antialias"     "1"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}
		DebugOverlay
		{
			"1"
			{
				"name"			"Courier New"
				"tall"			"14"
				"weight"		"400"
				"outline"		"1"
				"antialias"     "1"
				"range"			"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}
		CSType
		  {
		   "1"
		   {
				"name" 			"cs" // cs.ttf
				"tall"			"80"
				"weight" 		"0"
				"additive" 		"1"
				"antialias" 	"1"
				"outline"		"1"
		   }
		  }

		CSweapons // temporary, for testing. overlaps with CSType, above
		  {
		   "1"
		   {
				"name"  		"cstrike_icons" // Cstrike.ttf
				"tall"  		"70"
				"weight" 		"0"
				"additive" 		"1"
				"antialias" 	"1"
				"outline"		"1"
		   }
		  }
		CSBuy 
		  {
		   "1"
		   {
				"name"  		"cstrike_icons"
				"tall"  		"17"
				"weight" 		"0"
				"additive" 		"0"
				"antialias" 	"1"
				"outline"		"0"
		   }
		  }
		CSweaponsSmall 
		  {
		   "1"
		   {
				"name"  		"cstrike_icons" // Cstrike.ttf
				"tall"  		"60"
				"weight" 		"0"
				"additive" 		"1"
				"antialias" 	"1"
				"outline"		"1"
		   }
		  }
		ScenarioC4
		{
	    	"1"
      		{
	    		"name"		"cstrike_icons"
		     	"tall"		"13"
	     		"weight"	"0"
	     		"antialias"	"1"
				"additive"  "1"
	     	}
		}        
		HudNumbers2
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"  		"17"
				"weight"		"1"
				"additive" 		"0"
				"antialias" 	"0"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}
		HudNumbers3
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"  		"22"
				"weight"		"1"
				"additive" 		"0"
				"antialias" 	"0"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}
		HudNumbers4
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"  		"24"
				"weight"		"1"
				"additive" 		"0"
				"antialias" 	"0"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}
		HudNumbers5
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"  		"19"
				"weight"		"1"
				"additive" 		"0"
				"antialias" 	"0"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}
		CSTypeSmall
		  {
		   "1"
		   {
				"name"  		"cs" // cs.ttf
				"tall"  		"40"
				"weight" 		"20"
				"additive" 		"1"
				"antialias" 	"1"
		   }
		  }		  
		  CSTypelr
		  {
		   "1"
		   {
				"name"  		"cs" // cs.ttf
				"tall"  		"30"
				"weight" 		"0"
				"additive" 		"1"
				"antialias" 	"1"
		   }
		  }
		  CSTypeDeath
		  {
		   "1"
		   {
			"name"  		"csd_icons"
			"tall"  		"19"
			"weight" 		"1"
			"additive" 		"1"
			"antialias" 	"1"
            "custom"        "1"				
        }
      }
      "CS2Buy" 
		  {
		   "1"
		   {
			"name"  		"csd_icons"
			"tall"  		"19"
			"weight" 		"1"
			"additive" 		"1"
			"antialias" 	"1"
            "custom"        "1"				
		   }
		  }
		  CSTypeDeathSmall
		  {
		   "1"
		   {
			"name"  		"csd_icons" 
			"tall"  		"30"
			"weight" 		"1"
			"additive" 		"1"
			"antialias" 	"1"
            "custom"        "1"	
		   }
		  }
		  CSTypeDeath2Small
		  {
		   "1"
		   {
			"name"  "csd2"
			"tall"  "15"
			"weight" "1"
			"additive" "1"
			"antialias" "1"
			"custom" "1"
		   }
		  }		  
		  CStypeHud
		  {
		   "1"
		   {
				"name"  		"cstrike_icons" // Cstrike.ttf
				"tall"  		"25"
				"weight" 		"1"
				"additive" 		"1"
				"antialias" 	"1"
				"outline" 		"0"
				"custom"        "1"
				
		   }
		  }
		  
		  CStypeAccount
		  {
		   "1"
		   {
				"name"  		"cstrike_icons" // Cstrike.ttf
				"tall"  		"18"
				"weight" 		"1"
				"additive" 		"1"
				"antialias" 	"1"
				"outline" 		"0"
				"italic"		"0"
				
		   }
		  }
		  BuyMenuMainButtons
		{
		   "1"
		   {
				"name"  		"StratumNo2" // StratumNo2Black.ttf
				"tall"  		"0"
				"weight" 		"0"
				"additive" 		"0"
				"antialias" 	"0"
				"outline" 		"0"
				"italic"		"0"
		   }
		}		
		Icons
		{
			"1"
			 {
			"name"  "cstrike_icons" // Cstrike.ttf
			"tall"  "28"
			"weight" "0"
			"additive" "1"
			"antialias" "1"
			 }
		}
		IconsSmall
		{
			"1"
			 {
			"name"  "cstrike_icons" // Cstrike.ttf
			"tall"  "28"
			"weight" "0"
			"additive" "0"
			"antialias" "1"
			"custom" "1" [$OSX]
			 }
		}
	
		SpecIconsTimer
		{
			"1"
			 {
			"name"  "cstrike_icons" // Cstrike.ttf
			"tall"  "28"
			"weight" "0"
			"additive" "1"
			"antialias" "1"
			 }
		}

		"BetaFont"
		{
			"1"
			{
				"name"		"Courier New"
				"tall"		"90"
				"weight"	"900"
				"range"		"0x0000 0x007F"	//	Basic Latin
				"antialias" "1"
				"additive"	"0"
			}
		}
		HudNumbersAccount
		{
			"1"
			{
				"name"          "StratumNo2"
				"tall"  		"19"
				"weight"		"400"
				"additive" 		"0"
				"antialias" 	"1"
			}
		}

//new
		"RadioMenu"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"HealthArmorFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"22"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"ArmorFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"		"0"
				"antialias"	"1"
			}
      }
		"NotificationTextFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"ProgressTextFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"7"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"AlertFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"NotificationTitleFont"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"20"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"AccountFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"18"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"RoundTimerFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"AliveCountFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"21"
				"weight"		"0"
				"antialias"	"1"
				"dropshadow"	"1"
			}
		}
		"AliveTextFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"7"
				"weight"		"1200"
				"antialias"	"1"
				"dropshadow"	"1"
			}
		}
		"AmmoClipFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"25"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"AmmoMaxClipFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"15"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"LocationFont"
		{
			"1"
			{
				"name"		"Stratum2 Medium"
				"tall"		"14"
				"weight"		"0"
				"antialias"	"1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"		"600"
				"antialias"	"1"
			}
		}


		HudNumbersHealth
		{
			"1"
			{
				"name"          "StratumNo2Black"
				"tall"  		"21"
				"weight"		"900"
				"additive" 		"0"
				"antialias" 	"1"
			}
		}
		dgd	
		{
		"1"
			 {
			"name"  "dgd" // Cstrike.ttf
			"tall"  "100"
			"weight" "0"
			"additive" "0"
			"antialias" "1"	
			}
		}
		HudNumbers
		{
			"1"
			{
				"name"          "StratumNo2Black"
				"tall"  		"15"
				"weight"		"400"
				"additive" 		"0"
				"antialias" 	"1"
			}
		}        
		HudNumbersTimer
		{
			"1"
			{
				"name"          "StratumNo2Black"
				"tall"  		"13"
				"weight"		"400"
				"additive" 		"0"
				"antialias" 	"1"
			}
		}
		HudNumbersPlayerAlive
		{
			"1"
			{
				"name"          "StratumNo2Black"
				"tall"  		"27"
				"weight"		"400"
				"additive" 		"0"
				"antialias" 	"1"
                "dropshadow"    "1"
			}
		}        
		HudAccount
		{
			"1"
			{
				"name"          "StratumNo2Black"
				"tall"  		"19"
				"weight"		"700"
				"additive" 		"1"
				"antialias" 	"1"
			}
		}		
		HudNumbersDollar
		{
			"1"
			{
				"name"  "StratumNo2"
				"tall"  		"18"
				"weight"		"0"
				"additive" 		"1"
				"antialias" 	"1"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}				
		SpecScore
		{
			"1"
			{
				"name"  "StratumNo2"
				"tall"  		"20"
				"weight"		"0"
				"additive" 		"1"
				"antialias" 	"1"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}
		BuyMenuPrices
		{
			"1"
			{
				"name"     "StratumNo2" // NotoSans-Bold.ttf
				"tall"  		"11"
				"weight" 		"700"
				"additive" 		"0"
				"antialias" 	"1"
				"outline" 		"0"
				"italic"		"0"
                "custom"        "1"				
			}			
		}
		BuyMenuIcons
		{
		   "1"
		   {
				"name"  		"csd_icons"
				"tall"  		"50"
				"weight" 		"1"
				"antialias" 	"1"
				"custom"        "1"	
				
		   }
		}
		BuyMenuEquipIcons
		{
		   "1"
		   {
				"name"  		"Equipments"
				"tall"  		"25"
				"weight" 		"1"
				"antialias" 	"1"
				"custom"        "1"	
				
		   }
		}
		BuyMenuEquipIcons2
		{
		   "1"
		   {
				"name"  		"Equipments"
				"tall"  		"20"
				"weight" 		"1"
				"antialias" 	"1"
				"custom"        "1"	
				
		   }
		}
		HudEquip
		{
		   "1"
		   {
				"name"  		"Equipments"
				"tall"  		"47"
				"weight" 		"1"
				"additive" 		"1"
				"antialias" 	"1"
				"outline" 		"0"
				"italic"		"0"
				"custom"        "1"	
				
		   }
		}		
		BuyMenuNames
		{
		   "1"
		   {
				"name"  		"StratumNo2"
				"tall"  		"11"
				"weight" 		"400"
				"additive" 		"0"
				"antialias" 	"1"		
		   }
		}
		BuyMenuNameslarge
		{
		   "1"
			{
				"name"		    "StratumNo2"
				"tall"		    "13"
				"weight"	    "700"
				"additive" 		"0"
				"antialias" 	"1"
			}			
		}
		TeamMenuTeamNameFont
		{
		   "1"
			{
				"name"		    "StratumNo2"
				"tall"		    "21"
				"weight"	    "700"
				"additive" 		"0"
				"antialias" 	"1"
			}			
		}		
		TeamMenuPlayerCountFont
		{
		   "1"
			{
				"name"		    "StratumNo2"
				"tall"		    "10"
				"weight"	    "700"
				"additive" 		"0"
				"antialias" 	"1"
			}			
		}		
		BuyMenuStats
		{
			"1"
			{
				"name"          "StratumNo2Black" // NotoSans-Bold.ttf
				"tall"  		"8"
				"weight" 		"700"
				"additive" 		"0"
				"antialias" 	"1"
			}			
		}
		BuyMenuStatsLarge 
		{
			"1"
			{
				"name"          "StratumNo2" // NotoSans-Bold.ttf
				"tall"  		"12"
				"weight" 		"700"
				"additive" 		"0"
				"antialias" 	"1"
				"dropshadow"    "1"
			}			
		}
		BuyMenuStatsLargeOutline
		{
			"1"
			{
				"name"     "StratumNo2" // NotoSans-Bold.ttf
				"tall"  		"12"
				"weight" 		"700"
				"additive" 		"1"
				"antialias" 	"1"
				"outline"       "1"
				"dropshadow"    "1"
			}			
		}		
		BuyMenuFontButtons
		{
			"1"
			{
				"name"          "StratumNo2Black"
				"name"          "StratumNo2"
				"tall"  		"11"
				"weight"		"600"
				"additive" 		"0"
				"antialias" 	"1"
			}
		}
		BuyMenuFontButtons2
		{
			"1"
			{
				"name"          "StratumNo2"
				"name"          "StratumNo2"
				"tall"  		"14"
				"weight"		"600"
				"additive" 		"0"
				"antialias" 	"1"
			}
		}
		NullText
		{
			"1"
			{
				"name"          "NullText" //NullText.ttf
				"tall"  		"0"
				"weight"		"0"
				"additive" 		"0"
				"antialias" 	"0"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}		
		SpecScoreTimer
		{
			"1"
			{
				"name"          "StratumNo2"
				"name"          "StratumNo2"
				"tall"  		"15"
				"weight"		"90"
				"additive" 		"0"
				"antialias" 	"1"
				"dropshadow"	"0"
				"outline"		"0"
			}
		}
		ClockTimer
		{
			"1"
			{
				"name"  "Impossible - 500"
				"tall"  		"13"
				"weight"		"0"
				"additive" 		"0"
				"antialias" 	"1"
				"dropshadow"	"1"
				"outline"		"0"
			}
		}
		HudNumbersSmall
		{
			"1"
			{
				"name"			"StratumNo2"
				"tall"			"16"
				"weight"		"1000"
				"additive"		"1"
				"antialias"	 	"1"
				"range"			"0x0000 0x017F"
			}
		}
		"CloseCaption_Normal"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"500"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}
		"CloseCaption_Italic"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"500"
				"italic"	"0"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}
		"CloseCaption_Bold"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"900"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}
		"CloseCaption_BoldItalic"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"900"
				"italic"	"0"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
			}
		}
		// this is the symbol font
		"Marlett"
		{
			"1"
			{
				"name"		"Marlett"
				"tall"		"11"
				"weight"	"0"
				"symbol"	"1"
				"antialias"     "1"
				"range"		"0x0000 0x007F"	//	Basic Latin
			}
		}
		"MenuTitle"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"600"
				"outline"	"0"
				"antialias"     "1"
			}
		}
		"MenuTitle2"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"500"
				"antialias"     "1"
				"outline"		"1"
			}
		}
		"MenuTitle3"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"500"
				"antialias"     "1"
				"outline"		"1"
			}
		}
		"Trebuchet24"
		{
			"1"
			{
				"name"		"Trebuchet MS"
				"tall"		"24"
				"weight"	"900"
				"range"		"0x0000 0x007F"	//	Basic Latin
				"antialias" "1"
				"additive"	"1"
			}
		}
		"Trebuchet20"
		{
			"1"
			{
				"name"		"Trebuchet MS"
				"tall"		"20"
				"weight"	"900"
				"range"		"0x0000 0x007F"	//	Basic Latin
				"antialias" "1"
				"additive"	"1"
			}
		}
		"Trebuchet18"
		{
			"1"
			{
				"name"		"Trebuchet MS"
				"tall"		"18"
				"weight"	"900"
				"range"		"0x0000 0x007F"	//	Basic Latin
				"antialias" "1"
				"additive"	"1"
			}
		}
		"TargetID"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"700"
				"yres"	"480 599"
				"dropshadow"	"1"
				"additive"  "1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"700"
				"yres"	"600 767"
				"dropshadow"	"1"
				"additive"  "1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"700"
				"yres"	"768 1023"
				"dropshadow"	"1"
				"additive"  "1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"700"
				"yres"	"1024 1199"
				"dropshadow"	"1"
				"additive"  "1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"700"
				"yres"	"1200 10000"
				"dropshadow"	"1"
				"additive"  "1"
			}
		}		
		"ChatFont"
		{
			"1"
			{
				"name"		"StratumNo2"  
				"tall"		"12"
				"weight"	"700"
				"yres"	"480 599"
				"dropshadow"	"1"
            "additive" "1" 
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"700"
				"yres"	"600 767"
				"dropshadow"	"1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"700"
				"yres"	"768 1023"
				"dropshadow"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"20"
				"weight"	"700"
				"yres"	"1024 1199"
				"dropshadow"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"24"
				"weight"	"700"
				"yres"	"1200 10000"
				"dropshadow"	"1"
			}
		}
	
		//Stolen from SourceScheme to make the fonts a little smaller
		"AchievementTitleFont"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"16"
				"weight"	"1200"
				"antialias" "1"
				"outline" "1"
			}
		}
		"AchievementDescriptionFont"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"12"
				"weight"	"1200"
				"antialias" "1"
				"outline" "1"
				"yres"		"0 480"
			}
			"2"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"16"
				"weight"	"1200"
				"antialias" "1"
				"outline" "1"
				"yres"	 "481 10000"
			}
		}	
		
		
		AchievementItemTitle	[$WIN32]
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica Bold" [$OSX]
				"weight"		"1200"
				"tall"			"11"
				"antialias"		"1"
			}
		}
		
		AchievementItemDescription	[$WIN32]
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"weight"		"800"
				"tall"			"9"
				"antialias"		"1"
			}
		}
		
		AchievementPopupTitle	[$WIN32]
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica Bold" [$OSX]
				"weight"		"1200"
				"tall"			"12"
				"antialias"		"1"
			}
		}
		
		AchievementPopupDescription	[$WIN32]
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"weight"		"700"
				"tall"			"9"
				"antialias"		"1"
			}
		}
			"HUDAchievementTiny"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"6"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"8"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"768 959"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"960 1023"
				"antialias"	"1" [!$OSX]
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"1024 1199"
				"antialias"	"1" [!$OSX]
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"1200 6000"
				"antialias"	"1" [!$OSX]
			}
		}	
		"FreezeSmall"
		{		
			"1"
			{
				"name"		"StratumNo2Black" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"9"
				"weight"	"900"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A			
				"antialias"	"1" [!$OSX]
			}	
		}
		"FreezeName"
		{		
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"16"
				"weight"	"600"		
				"antialias"	"1"
			}	
		}
		"FreezeTiny"
		{		
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"10"
				"weight"	"600"		
				"antialias"	"1"
				"additive"  "1"
			}	
		}
		"FreezeTiny2"
		{		
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"11"
				"weight"	"600"		
				"antialias"	"1"
				"dropshadow" "1"
			}	
		}		
		
		"FreezeMedium"	// used by the freeze panel
		{		
			"1"
			{
				"name"		"StratumNo2Black" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"14"
				"weight"	"600"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A				
				"antialias"	"1"
			}	
		}
		
		"FreezeLarge"
		{	
			"1"
			{
				"name"		"StratumNo2Black" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"18"
				"weight"	"600"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A				
				"antialias"	"1"
			}	
		}
		
		"WinLabelMD2"
		{
			"1"
			{
				"name"		"StratumNo2Black" //"StratumNo2"
				"tall"		"16"
				"weight"	"500"
				"antialias" "1"
				"bold"		"1"
				"dropshadow" "1"
				
			}
		}

		"WinPanelLarge"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"18"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"1"
			}
		}
		"WinPanelLarge2"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"18"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"0"
			}
		}
		"TeamsLabel"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"5"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"0"
			}
		}
		"ScoreServerName"
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"		"8"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"outline"	"0"
			}
		}
		"ScoreStats"
		{
			"1"
			{
				"name"         "StratumNo2Black"
				"tall"		   "9"
				"weight"	   "400"
				"range"		   "0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	   "1"
			}
		}
		"ScoreSpec"
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"		"12"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"outline"	"0"
			}
		}
		"ScoreCondition"
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"		"10"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"outline"	"0"
			}
		}		
		"ScoreBoardMapName"
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"	     "10"
				"weight"	 "Bold"
				"antialias"  "1"
				"dropshadow" "0"
				"outline"	 "0"
			}
		}
		"ScoreBoardMapName2"
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"	     "11"
				"weight"	 "Bold"
				"antialias"  "1"
				"dropshadow" "0"
				"outline"	 "0"
			}
		}
		"ScoreBoardTeamLabel"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"6"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"0"
			}
		}
		"WinPanelLarge4"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"8"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"0"
			}
		}
		"ScoreboardMaPname"
		{
			"1"
			{
				"name"  "StratumNo2Black"
				"tall"		"11"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"outline"	"0"
			}
		}		
		"WinPanelLarge5"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"Helvetica" [$OSX]
				"tall"		"13"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"0"
			}
		}
		"WinPanelMvp"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"1"
				"custom"        "0"	
			}
		}
		"WinPanelTitle"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow"	"1"
				"custom"        "0"	
			}
		}
		"WinPanelLarge5"
		{
			"1"
			{
				"name"		"StratumNo2"
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"outline"	"0"
				"dropshadow"	"0"
			}
		}

		"WinPanelTiny"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"12" 
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"1"
			}
		}
		"WinPanelFun"
		{
			"1"
			{
				"name"		"StratumNo2 Bold"
				"tall"		"6" 
				"weight"	"700"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"0"
				"dropshadow" "0"
				"custom"        "0"	
			}
		}		
		"KillFeed"
		{
			"1"
			{
				"name"		  "StratumNo2"
				"tall"		  "15" 
				"weight"	  "600"
				"dropshadow"  "1"
				"antialias"	  "1" 
				"additive"    "1"
				"outline"	  "0"				
			}
		}
		"LocationStratum"
		{
			"1"
			{
				"name"		  "StratumNo2" 
				"tall"		  "14" 
				"weight"	  "600"
				"dropshadow"  "1"
				"antialias"	  "1" 
				"additive"    "1"
				"outline"	  "0"				
			}
		}	
		"VoiceStatusFont"
		{
			"1"
			{
				"name"		  "StratumNo2" 
				"tall"		  "14" 
				"weight"	  "600"
				"dropshadow"  "1"
				"antialias"	  "1" 
				"additive"    "1"
				"outline"	  "0"				
			}
		}	
		"MoneySpec"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"19" 
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"1"
				"color" "255 255 255 255"
			}
		}
		"WinPanelTiny7"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"9" 
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"1"
			}
		}
		
		"WinPanelTiny4"
		{
			"1"
			{
				"name"		"StratumNo2" [!$OSX]
				"name"		"StratumNo2" [$OSX]
				"tall"		"14" 
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1" [!$OSX]
				"outline"	"1"
			}
		}

		WinPanelClock
		{
			"1"
			{
				"name"		"cstrike_icons" // Cstrike.ttf
				"tall"		"18"
				"weight"	"0"
				"additive"	"1"
				"antialias"	"1"
			}
		}

		"HUDAchievementTiny"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"6"
				"weight"	"0"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"480 599"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"8"
				"weight"	"0"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"600 767"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"768 959"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"960 1023"
				"antialias"	"1" [!$OSX]
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"1024 1199"
				"antialias"	"1" [!$OSX]
			}
			"6"
			{
				"name"		"StratumNo2"
				"tall"		"16"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"yres"		"1200 6000"
				"antialias"	"1" [!$OSX]
			}
		}

		"ScoreboardHeader"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"8"
				"weight"	"0"
				"antialias"     "1"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"outline"	"0"
			}
		}

		"ScoreboardTeamName"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"15"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"additive"	"0"
			}
		}
		"SpecTitle"
		{
			"1"
			{
				"name"  "StratumNo2"
				"tall"		"20"
				"weight"	"600"
				"antialias"	"1"
				"additive"  "1"
			}
		}		

		"ScoreboardScore"
		{
			"1"
			{
				"name"      "StratumNo2"
				"tall"		"35"
				"weight"	"700"
				"antialias"	"1"
				"custom"    "0"

			}
		}

		"SpecScoreboardTeamName"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"additive"	"0"
			}
		}

		"SpecTeamImage"
		{
			"1"
			{
				"name"		"CSTeams"
				"tall"		"50"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"additive"	"1"
			}
		}

		"SpecScoreboardScore"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"33"
				"weight"	"0"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
				"dropshadow"	"0"
				"additive"	"0"
			}
		}
		"SpecPlayer"
		{
			"1"
			{
				"name"		"StratumNo2" 
				"tall"		"16"
				"weight"	"1000"
				"range"		"0x0000 0x017F" //	Basic Latin, Latin-1 Supplement, Latin Extended-A
				"antialias"	"1"
			}
		}

		"SpecPlayerName"
		{
			"1"
			{
				"name"		"StratumNo2"//StratumNo2
				"tall"		"11"
				"weight"	"1000"
				"antialias"     "1"
				"yres"		"480 599"
				"outline"	"1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"12"
				"weight"	"1000"
				"antialias"     "1"
				"yres"		"600 767"
				"outline"	"1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"1000"
				"antialias"     "1"
				"yres"		"768 1023"
				"outline"	"1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"1000"
				"antialias"     "1"
				"yres"		"1024 1199"
				"outline"	"1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"21"
				"weight"	"1000"
				"antialias"     "1"
				"yres"		"1200 10000"
				"outline"	"1"
			}
		}

		"Scoreboard_Nums"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"400"
				"yres"		"480 599"
				"outline"	"0"
				"antialias" "1"
				"custom"        "0"	
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"400"
				"yres"		"600 767"
				"outline"	"0"
				"antialias" "1"
				"custom"        "0"	
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"400"
				"yres"		"768 1023"
				"outline"	"0"
				"antialias" "1"
				"custom"        "0"	
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"400"
				"yres"		"1024 1199"
				"outline"	"0"
				"antialias" "1"
				"custom"        "0"	
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"400"
				"yres"		"1200 10000"
				"outline"	"0"
				"antialias" "1"
				"custom"        "0"	
			}
		}
		
		"ScoreboardColumns"
		{
			"1"
			{
				"name"		"StratumNo2Black" //StratumNo2Black
				"tall"		"11"
				"weight"	"1000"
				"yres"		"480 599"
				"outline"	"0"
				"antialias" "1"
			}
			"2"
			{
				"name"		"StratumNo2"
				"tall"		"11"
				"weight"	"1000"
				"yres"		"600 767"
				"outline"	"0"
				"antialias" "1"
			}
			"3"
			{
				"name"		"StratumNo2"
				"tall"		"13"
				"weight"	"1000"
				"yres"		"768 1023"
				"outline"	"0"
				"antialias" "1"
			}
			"4"
			{
				"name"		"StratumNo2"
				"tall"		"14"
				"weight"	"1000"
				"yres"		"1024 1199"
				"outline"	"0"
				"antialias" "1"
			}
			"5"
			{
				"name"		"StratumNo2"
				"tall"		"21"
				"weight"	"1000"
				"yres"		"1200 10000"
				"outline"	"0"
				"antialias" "1"
			}
		}
		"WeaponSelectionNameLabelFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"WeaponSelectionCountLabelFont"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"10"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		"WeaponSelectionSlotLabelFont"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"10"
				"weight"		"0"
				"antialias"	"1"
			}
		}
		
		"ScoreboardPlayersAlive"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"8"
				"weight"	"400"
				"antialias"	"1"
				"custom"    "0"
			}
		}
		"ScoreboardPlayersAlive2"
		{
			"1"
			{
				"name"		"StratumNo2Black"
				"tall"		"7"
				"weight"	"400"
				"antialias"	"1"
				"custom"    "0"
			}
		}
		"ScoreboardPlayersName"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"600"
				"antialias"	"1"
			}
		}		

		"ScoreboardBody_1"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"600"
				"outline"	"0"
				"antialias" "1"					
			}
		}

		"ScoreboardBody_2"
		{
			"1"
			{
				"name"		"StratumNo2" 
				"tall"		"9" 
				"weight"	"600"
				"outline"	"0"
				"antialias" "1" 
			}
		}

		"ScoreboardBody_3"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"600"
				"outline"	"0"
				"antialias" "1" 
			}
		}

		"ScoreboardMVP"
		{
			"1"
			{
				"name"		"StratumNo2"
				"tall"		"9"
				"weight"	"400"
				"antialias"	"1"
			}
		}	
	}

	Borders
	{
		BaseBorder
		{
			"inset" "0 0 1 1"
			Left
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 0"
				}
			}
		}
		
		TitleButtonBorder
		{
			"inset" "0 0 1 1"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}

		TitleButtonDisabledBorder
		{
			"inset" "0 0 1 1"
			Left
			{
				"1"
				{
					"color" "BgColor"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "BgColor"
					"offset" "1 0"
				}
			}
			Top
			{
				"1"
				{
					"color" "BgColor"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "BgColor"
					"offset" "0 0"
				}
			}
		}

		TitleButtonDepressedBorder
		{
			"inset" "1 1 1 1"
			Left
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}
		}

		ScrollBarButtonBorder
		{
			"inset" "1 0 0 0"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}

		ScrollBarButtonDepressedBorder
		{
			"inset" "2 2 0 0"
			Left
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}
		}
		
		ButtonBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}

		FrameBorder
		{
			"inset" "0 0 1 1"
			Left
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "000 000 000 000"
					"offset" "0 0"
				}
			}
		}

		TabBorder
		{
			"inset" "0 0 1 1"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}
		}

		TabActiveBorder
		{
			"inset" "0 0 1 0"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "ControlBG"
					"offset" "6 2"
				}
			}
		}


		ToolTipBorder
		{
			"inset" "0 0 1 0"
			Left
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}

		// this is the border used for default buttons (the button that gets pressed when you hit enter)
		ButtonKeyFocusBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}

		ButtonDepressedBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}

		ComboBoxBorder
		{
			"inset" "0 0 1 1"
			Left
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}
		}

		MenuBorder
		{
			"inset" "1 1 1 1"
			Left
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "1 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}
		}
		BrowserBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "0 0"
				}
			}
		}
		BuyPresetBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Border.BuyPreset"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.BuyPreset"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.BuyPreset"
					"offset" "1 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Border.BuyPreset"
					"offset" "0 0"
				}
			}
		}

		BuyPresetButtonBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Blank"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Border.Dark"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Border.Bright"
					"offset" "1 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Blank"
					"offset" "0 0"
				}
			}
		}

        BlackBorder
		{
			"inset" "0 0 0 0"
			Left
			{
				"1"
				{
					"color" "Black"
					"offset" "0 1"
				}
			}

			Right
			{
				"1"
				{
					"color" "Black"
					"offset" "0 0"
				}
			}

			Top
			{
				"1"
				{
					"color" "Black"
					"offset" "1 1"
				}
			}

			Bottom
			{
				"1"
				{
					"color" "Black"
					"offset" "0 0"
				}
			}
		}		
	}

	CustomFontFiles
	{
		"1"		"resource/cs.ttf"
		"2"		"resource/csd_icons.ttf"
		"3"		"resource/csd2.ttf"
		"4"		"resource/cstrike_icons.ttf"
		"5"		"resource/CSlogo.ttf"
		"6"		"resource/new_fonts/Stratum2-Bold.ttf"
		"7"		"resource/new_fonts/Stratum2-Medium.ttf"
		"8"	    "resource/new_fonts/NewMenu.ttf"
		"9"	    "resource/new_fonts/Null-Text.ttf"
		"10"	"resource/new_fonts/NotoSans-Bold.ttf"
		"11"	"resource/new_fonts/NotoSans-BoldItalic.ttf"
		"12"	"resource/new_fonts/NotoSans-Italic.ttf"
		"13"	"resource/new_fonts/NotoSans-Regular.ttf"
		"14"	"resource/new_fonts/StartIcons.ttf"
		"15"	"resource/new_fonts/Equipments.ttf"
        "16"	"resource/new_fonts/Stratum2Dollar.ttf"
        "17"	"resource/new_fonts/Stratum2HudNumbers-Bold.ttf"
        "18"	"resource/new_fonts/StratumNo2Black.ttf"
		"19"	"resource/new_fonts/MainMenu.ttf"
		"20"   "resource/Cstrike.ttf"
		"21"		"resource/new_fonts/stratum2bold.ttf"
		"22"		"resource/new_fonts/stratum2medium.ttf"
		"23"		"resource/new_fonts/stratum2regular.ttf"
		"24"		"resource/new_fonts/stratum2bold_monodigit.ttf"
		"25"		"resource/new_fonts/stratum2regular_monodigit.ttf"
		"26"	"resource/notosans-regular.ttf"
		"27"	"resource/notosans-bold.ttf"
		"28"	"resource/new_fonts/stratum.ttf"
		"29"	"resource/csgo_fonts/stratum2bold.ttf"
		"30"		"resource/fonts/StratumNo2.ttf"
  "31"     "resource/GMCX_ICO1.ttf" 
  "32" "resource/RIFLES.ttf"
  "33"  "resource/Myfont-Regular.ttf"
  "34"   "resource/Test1-Regular.ttf"
	}
}
